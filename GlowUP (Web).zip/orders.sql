CREATE TABLE orders (
   id INT PRIMARY KEY AUTO_INCREMENT,
   name VARCHAR(50),
   email VARCHAR(50),
   payment_method VARCHAR(50),
   address VARCHAR(100),
   phone VARCHAR(20)
 
);