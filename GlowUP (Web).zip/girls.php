<!DOCTYPE html>
<html>

<head>
    <title>GlowUp-Clothes Kids girls</title>

    <link rel="stylesheet" type="text/css" href="style4.css">
    <script src="script4.js"></script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>
<header>
<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
    <div class="container">
        <a class="navbar-brand" href="#">
            <h4>
                <em>GlowUp</em>
            </h4>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
            aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="Women.php">Women</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="Men.php">Men</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="girls.php">Kids girls</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="boys.php">Kids boys</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="ShoppingBag.php">
                        <img src="https://th.bing.com/th/id/OIP.SlPKG8oNNf7REyoldslkIQHaHa?rs=1&pid=ImgDetMain" alt="Shopping Bag" width="20" height="20"> Shopping Bag
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

</header>
    
    <div class="product-cards-container">

        <div class="product-card">
            <div class="shoe-details">
                <img src="https://sa.hm.com/assets/styles/HNM/17312146/41c2ebefd4b1f49d151711a235c01fbf280df98c/1/image-thumb__5373004__product_zoom_large_800x800/41c2ebefd4b1f49d151711a235c01fbf280df98c.jpg"
                    alt="Product 1">
                <span class="shoe-name">Lace-detail blouse</span>
                <p>This lace-detail blouse is a versatile addition to your wardrobe.<br />
                     It features intricate lace detailing and a stylish design that can be dressed up or down.<br />
                      Made from high-quality materials, it offers both comfort and style.<br />
                     Pair it with jeans or a skirt for a chic and trendy look.</p>
                <div class="stars bx">
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bx-star"></i>
                </div>
            </div>

            <div class="color-size-price">
                <div class="color-option">
                    <span class="color">Color:</span>
                    <div class="circles">
                        <span class="circle beige active" id="beige"></span>
                        <span class="circle black" id="black"></span>
                        <span class="circle brown" id="brown"></span>
                    </div>
                </div>


                <div class="size-option">
                    <span class="size">Size:</span>
                    <div class="sizes">
                        <span class="size-option">5</span>
                        <span class="size-option">6</span>
                        <span class="size-option">7</span>
                        <span class="size-option">8</span>
                        <span class="size-option">9</span>
                        <span class="size-option">10</span>
                        <span class="size-option">11</span>
                        <span class="size-option">12</span>
                        <span class="size-option">13</span>
                        <span class="size-option">14</span>
                    </div>
                </div>

                <div class="price">
                    <span class="price_num">$200.99</span>
                </div>
            </div>

            <div class="button">
                <button class="add-to-bag">Add to Bag</button>
            </div>
        </div>


        <div class="product-card">
            <div class="shoe-details">
                <img src="https://sa.hm.com/assets/styles/HNM/17083883/ec8fba1e1794acd04eec9d8c1e13b35ab0cdd019/1/image-thumb__5152775__product_zoom_large_800x800/ec8fba1e1794acd04eec9d8c1e13b35ab0cdd019.jpg"
                    alt="Product 2">
                <span class="shoe-name">Wide jogger</span>
                <p>Introducing our new wide jogger shoes, perfect for comfort and style.<br />
                     These shoes feature a spacious design that accommodates wider feet without compromising on fashion.<br />
                     Step out with confidence and enjoy a trendy look with these versatile joggers.</p>
                <div class="stars bx">
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bx-star"></i>
                </div>
            </div>

            <div class="color-size-price">
                <div class="color-option">
                    <span class="color">Color:</span>
                    <div class="circles">
                        <span class="circle beige active" id="beige"></span>
                        <span class="circle black" id="black"></span>
                        <span class="circle brown" id="brown"></span>
                    </div>
                </div>
                <div class="size-option">
                    <span class="size">Size:</span>
                    <div class="sizes">
                        <span class="size-option">5</span>
                        <span class="size-option">6</span>
                        <span class="size-option">7</span>
                        <span class="size-option">8</span>
                        <span class="size-option">9</span>
                        <span class="size-option">10</span>
                        <span class="size-option">11</span>
                        <span class="size-option">12</span>
                        <span class="size-option">13</span>
                        <span class="size-option">14</span>
                    </div>
                </div>

                <div class="price">
                    <span class="price_num">$199.99</span>
                </div>
            </div>

            <div class="button">
                <button class="add-to-bag">Add to Bag</button>
            </div>
        </div>


        <div class="product-card">
            <div class="shoe-details">
                <img src="https://sa.hm.com/assets/styles/HNM/16961534/cea5dd8b0de0fbb8de60e06a066e2f0f82ff705b/1/image-thumb__5030000__product_zoom_large_800x800/cea5dd8b0de0fbb8de60e06a066e2f0f82ff705b.jpg"
                    alt="Product 3">
                <span class="shoe-name">Wide trousers</span>
                <p>These wide trousers are designed for both style and comfort. Made from high-quality fabric, they feature a relaxed fit and a flattering silhouette.<br />
                     Perfect for any occasion, these trousers can be dressed up or down to suit your personal style.<br />
                      Pair them with a blouse and heels for a sophisticated look, or dress them down with a t-shirt and sneakers for a more casual ensemble.<br />
                     Available in multiple colors and sizes, these wide trousers are a versatile addition to your wardrobe.</p>
                <div class="stars bx">
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bx-star"></i>
                </div>
            </div>

            <div class="color-size-price">
                <div class="color-option">
                    <span class="color">Color:</span>
                    <div class="circles">
                        <span class="circle beige active" id="beige"></span>
                        <span class="circle black" id="black"></span>
                        <span class="circle brown" id="brown"></span>
                    </div>
                </div>


                <div class="size-option">
                    <span class="size">Size:</span>
                    <div class="sizes">
                        <span class="size-option">5</span>
                        <span class="size-option">6</span>
                        <span class="size-option">7</span>
                        <span class="size-option">8</span>
                        <span class="size-option">9</span>
                        <span class="size-option">10</span>
                        <span class="size-option">11</span>
                        <span class="size-option">12</span>
                        <span class="size-option">13</span>
                        <span class="size-option">14</span>
                    </div>
                </div>

                <div class="price">
                    <span class="price_num">$175.99</span>
                </div>
            </div>

            <div class="button">
                <button class="add-to-bag">Add to Bag</button>
            </div>
        </div>


        <div class="product-card">
            <div class="shoe-details">
                <img src="https://sa.hm.com/assets/styles/HNM/17217850/5337978774292c9a39cfadce3415cf90d607ce37/1/image-thumb__5318197__product_zoom_large_800x800/5337978774292c9a39cfadce3415cf90d607ce37.jpg"
                    alt="Product 4">
                <span class="shoe-name">Dinty sweater</span>
                <p>This cozy sweater is perfect for chilly weather. It features a soft fabric and a stylish design that will keep you warm and fashionable.<br />
                      Pair it with your favorite jeans for a casual yet trendy look.</p>
                <div class="stars bx">
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bx-star"></i>
                </div>
            </div>
            <div class="color-size-price">
                <div class="color-option">
                    <span class="color">Color:</span>
                    <div class="circles">
                        <span class="circle beige active" id="beige"></span>
                        <span class="circle black" id="black"></span>
                        <span class="circle brown" id="brown"></span>
                    </div>
                </div>


                <div class="size-option">
                    <span class="size">Size:</span>
                    <div class="sizes">
                        <span class="size-option">5</span>
                        <span class="size-option">6</span>
                        <span class="size-option">7</span>
                        <span class="size-option">8</span>
                        <span class="size-option">9</span>
                        <span class="size-option">10</span>
                        <span class="size-option">11</span>
                        <span class="size-option">12</span>
                        <span class="size-option">13</span>
                        <span class="size-option">14</span>
                    </div>
                </div>

                <div class="price">
                    <span class="price_num">$340.99</span>
                </div>
            </div>

            <div class="button">
                <button class="add-to-bag">Add to Bag</button>
            </div>
        </div>


        <div class="product-card">
            <div class="shoe-details">
                <img src="https://sa.hm.com/assets/styles/HNM/17061693/0bea7207ee683567b4b74db23ac36c92b3cf1452/1/image-thumb__5137649__product_zoom_large_800x800/0bea7207ee683567b4b74db23ac36c92b3cf1452.jpg"
                    alt="Product 5">
                <span class="shoe-name">Oversized hoodie</span>
                <p>This oversized hoodie is made from soft and comfortable fabric, perfect for casual and cozy wear. It features a relaxed fit and a kangaroo pocket for added convenience.<br />
                     Available in multiple colors and sizes, this hoodie is versatile and stylish. Stay warm and fashionable with this trendy oversized hoodie.</p>
                <div class="stars bx">
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bx-star"></i>
                </div>
            </div>

            <div class="color-size-price">
                <div class="color-option">
                    <span class="color">Color:</span>
                    <div class="circles">
                        <span class="circle beige active" id="beige"></span>
                        <span class="circle black" id="black"></span>
                        <span class="circle brown" id="brown"></span>
                    </div>
                </div>


                <div class="size-option">
                    <span class="size">Size:</span>
                    <div class="sizes">
                        <span class="size-option">5</span>
                        <span class="size-option">6</span>
                        <span class="size-option">7</span>
                        <span class="size-option">8</span>
                        <span class="size-option">9</span>
                        <span class="size-option">10</span>
                        <span class="size-option">11</span>
                        <span class="size-option">12</span>
                        <span class="size-option">13</span>
                        <span class="size-option">14</span>
                    </div>
                </div>

                <div class="price">
                    <span class="price_num">$400.99</span>
                </div>
            </div>

            <div class="button">
                <button class="add-to-bag">Add to Bag</button>
            </div>
        </div>


        <div class="product-card">
            <div class="shoe-details">
                <img src="https://sa.hm.com/assets/styles/HNM/17207119/6bfd58731b11cf67c86d9d91a5a16c584def7438/1/image-thumb__5291982__product_zoom_large_800x800/6bfd58731b11cf67c86d9d91a5a16c584def7438.jpg"
                 alt="Product 6">
                <span class="shoe-name">Ribbed dress</span>
                <p>This ribbed dress is perfect for any occasion. Its stylish design and comfortable fit make it a must-have addition to your wardrobe.<br />
                     Available in multiple colors and sizes, you can find the perfect fit for you. Add this dress to your bag now and elevate your style!</p>
                <div class="stars bx">
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bx-star"></i>
                </div>
            </div>
            <div class="color-size-price">
                <div class="color-option">
                    <span class="color">Color:</span>
                    <div class="circles">
                        <span class="circle beige active" id="beige"></span>
                        <span class="circle black" id="black"></span>
                        <span class="circle brown" id="brown"></span>
                    </div>
                </div>


                <div class="size-option">
                    <span class="size">Size:</span>
                    <div class="sizes">
                        <span class="size-option">5</span>
                        <span class="size-option">6</span>
                        <span class="size-option">7</span>
                        <span class="size-option">8</span>
                        <span class="size-option">9</span>
                        <span class="size-option">10</span>
                        <span class="size-option">11</span>
                        <span class="size-option">12</span>
                        <span class="size-option">13</span>
                        <span class="size-option">14</span>
                    </div>
                </div>

                <div class="price">
                    <span class="price_num">$290.99</span>
                </div>
            </div>

            <div class="button">
                <button class="add-to-bag">Add to Bag</button>
            </div>
        </div>
    </div>

    <div class="pagination-container">
        <a href="GlowUp.php" class="pagination-item">
            <img src="https://f.nooncdn.com/s/app/com/sivvi/design-system/icons-v2/chevron-back.svg" alt="chevronBack"
                class="pagination-icon" loading="eager">
        </a>

        <a href="girls.php" class="pagination-item">1</a>
        <a href="girls2.php" class="pagination-item">2</a>
        <span class="ellipsis">...</span>
        <a href="girls3.php" class="pagination-item">3</a>

        <a href="girls2.php" class="pagination-item">
            <img src="https://f.nooncdn.com/s/app/com/sivvi/design-system/icons-v2/chevron-forward.svg"
                alt="chevronForward" class="pagination-icon" loading="eager">
        </a>
    </div>

    <div class="c-footer" title="back to top">
        <button id="backtotop">&#8593;</button>
    </div>
    
</body>

</html>