-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 09, 2023 at 07:25 PM
-- Server version: 10.4.27-MariaDB
-- PHP Version: 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `glowup`
--

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `Id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `color` varchar(50) NOT NULL,
  `Size` varchar(20) NOT NULL,
  `price` decimal(10,2) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`Id`, `name`, `color`, `Size`, `price`, `quantity`) VALUES
(0, 'Coat', 'brown', 'XL', '244.99', 1),
(0, 'Dress sweater', 'beige', 'XS', '239.99', 1),
(0, 'Jacket', 'brown', 'S', '199.99', 1),
(0, 'Wide jogger', 'beige', '8', '199.99', 1),
(0, 'Dinty sweater', 'beige', '11', '340.99', 1),
(0, 'Jacket', 'beige', 'L', '199.99', 1),
(0, 'Hoodie', 'beige', 'M', '199.99', 1),
(0, 'Ribbed dress', 'black', '10', '290.99', 1),
(0, 'Sweatshirt', 'beige', '9', '190.99', 1),
(0, 'Sweatshirt', 'beige', '9', '190.99', 1);

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `payment_method` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `phone` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`name`, `email`, `payment_method`, `address`, `phone`) VALUES
('rahaf44', 'rrr4444@hotmail.com', 'cash on delivery', 'fvgcfg7gcg', '087643'),
('rahaf44', 'rrr4444@hotmail.com', 'cash on delivery', '1234street flat3 floorOne', '0569715256'),
('rahaf banat', 'rahaf@gmail.com', 'credit card', '1234street flat3 floorOne', '0546648076'),
('rahaf banat', 'rahaf@gmail.com', 'credit card', '1234street flat3 floorOne', '0546648076'),
('sara', 'sara@gmail.com', 'credit card', '1234street flat3 floorOne', '0546648076'),
('sara', 'sara@gmail.com', 'credit card', '1234street flat3 floorOne', '0546648076'),
('sara', 'sara@gmail.com', 'credit card', '1234street flat3 floorOne', '0546648076');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `Id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(255) NOT NULL,
  `price` decimal(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`Id`, `name`, `description`, `image`, `price`) VALUES
(1, 'Tie-front blouse', 'This Tie-front blouse is a versatile addition to your wardrobe. It features intricate lace detailing and a stylish design that can be dressed up or down. Made from high-quality materials, it offers both comfort and style. Pair it with jeans or a skirt for a chic and trendy look.', 'https://sa.hm.com/assets/styles/HNM/17226480/7f1498b7564ed38f1aed1b9274dc62b0b4735440/1/image-thumb__5325342__product_zoom_medium_606x504/7f1498b7564ed38f1aed1b9274dc62b0b4735440.jpg', '200.99'),
(2, 'Lace-detail blouse', 'This lace-detail blouse is a versatile addition to your wardrobe.<br />\r\n                     It features intricate lace detailing and a stylish design that can be dressed up or down.<br />\r\n                      Made from high-quality materials, it offers both comfort and style.<br />\r\n                     Pair it with jeans or a skirt for a chic and trendy look.', 'https://sa.hm.com/assets/styles/HNM/17312146/41c2ebefd4b1f49d151711a235c01fbf280df98c/1/image-thumb__5373004__product_zoom_large_800x800/41c2ebefd4b1f49d151711a235c01fbf280df98c.jpg', '200.99'),
(3, 'Wide jogger', 'Introducing our new wide jogger shoes, perfect for comfort and style.\r\n                     These shoes feature a spacious design that accommodates wider feet without compromising on fashion.\r\n                     Step out with confidence and enjoy a trendy look with these versatile joggers.', 'https://sa.hm.com/assets/styles/HNM/17083883/ec8fba1e1794acd04eec9d8c1e13b35ab0cdd019/1/image-thumb__5152775__product_zoom_large_800x800/ec8fba1e1794acd04eec9d8c1e13b35ab0cdd019.jpg', '199.99'),
(4, 'Wide trousers', 'hese wide trousers are designed for both style and comfort. Made from high-quality fabric, they feature a relaxed fit and a flattering silhouette.\r\n                     Perfect for any occasion, these trousers can be dressed up or down to suit your personal style.\r\n                      Pair them with a blouse and heels for a sophisticated look, or dress them down with a t-shirt and sneakers for a more casual ensemble.\r\n                     Available in multiple colors and sizes, these wide trousers are a versatile addition to your wardrobe.', 'https://sa.hm.com/assets/styles/HNM/16961534/cea5dd8b0de0fbb8de60e06a066e2f0f82ff705b/1/image-thumb__5030000__product_zoom_large_800x800/cea5dd8b0de0fbb8de60e06a066e2f0f82ff705b.jpg', '175.99'),
(5, 'Dinty sweater', 'This cozy sweater is perfect for chilly weather. It features a soft fabric and a stylish design that will keep you warm and fashionable.\r\n                      Pair it with your favorite jeans for a casual yet trendy look.', 'https://sa.hm.com/assets/styles/HNM/17217850/5337978774292c9a39cfadce3415cf90d607ce37/1/image-thumb__5318197__product_zoom_large_800x800/5337978774292c9a39cfadce3415cf90d607ce37.jpg', '340.99'),
(6, 'Oversized hoodie', 'This oversized hoodie is made from soft and comfortable fabric, perfect for casual and cozy wear. It features a relaxed fit and a kangaroo pocket for added convenience.\r\n                     Available in multiple colors and sizes, this hoodie is versatile and stylish. Stay warm and fashionable with this trendy oversized hoodie.', 'https://sa.hm.com/assets/styles/HNM/17061693/0bea7207ee683567b4b74db23ac36c92b3cf1452/1/image-thumb__5137649__product_zoom_large_800x800/0bea7207ee683567b4b74db23ac36c92b3cf1452.jpg', '400.99'),
(7, 'Ribbed dress', 'This ribbed dress is perfect for any occasion. Its stylish design and comfortable fit make it a must-have addition to your wardrobe. Available in multiple colors and sizes, you can find the perfect fit for you. Add this dress to your bag now and elevate your style!', 'https://sa.hm.com/assets/styles/HNM/17207119/6bfd58731b11cf67c86d9d91a5a16c584def7438/1/image-thumb__5291982__product_zoom_large_800x800/6bfd58731b11cf67c86d9d91a5a16c584def7438.jpg', '290.99'),
(8, 'dress', 'This dress is perfect for any occasion. It features a stylish design with a comfortable fit. Made from high-quality materials, it is both fashionable and durable. Choose your preferred color and size from the options provided.', 'https://sa.hm.com/assets/styles/HNM/17035452/dc8f7a3545514ea65ad732d4476e417c5dd99931/1/image-thumb__5108788__product_zoom_large_800x800/dc8f7a3545514ea65ad732d4476e417c5dd99931.jpg', '200.99'),
(9, 'Jacket', 'This jacket is a stylish and versatile addition to your wardrobe. It features a modern design with a comfortable fit. The high-quality material ensures durability and warmth, making it perfect for colder weather. Whether you\'re going for a casual or a more dressed-up look, this jacket is sure to elevate your style.', 'https://sa.hm.com/assets/styles/HNM/17092474/1c3b78449bdbba180e0ec77479c3317273c6845b/1/image-thumb__5180945__product_listing/1c3b78449bdbba180e0ec77479c3317273c6845b.jpg', '199.99'),
(10, 'Wide Leg Low Jeans', 'These Jeans are designed for both style and comfort. Made from high-quality fabric, they feature a relaxed fit and a flattering silhouette. Perfect for any occasion, these trousers can be dressed up or down to suit your personal style. Pair them with a blouse and heels for a sophisticated look, or dress them down with a t-shirt and sneakers for a more casual ensemble.', 'https://sa.hm.com/assets/styles/HNM/17015561/82ebe8e668116b953ea10522b256de83cd870a24/1/image-thumb__5090981__product_zoom_medium_606x504/82ebe8e668116b953ea10522b256de83cd870a24.jpg', '175.99'),
(11, 'Jacquard-knit jumper', 'This cozy  jumper is perfect for chilly weather. It features a soft fabric and a stylish design that will keep you warm and fashionable. Pair it with your favorite jeans for a casual yet trendy look.', 'https://sa.hm.com/assets/styles/HNM/17183150/c95cd99e5db3818b3fea5fdfb43d055d327e7d95/1/image-thumb__5257960__product_zoom_medium_606x504/c95cd99e5db3818b3fea5fdfb43d055d327e7d95.jpg', '340.99'),
(12, 'Oversized hoodie', 'This oversized hoodie is made from soft and comfortable fabric, perfect for casual and cozy wear. It features a relaxed fit and a kangaroo pocket for added convenience. Available in multiple colors and sizes, this hoodie is versatile and stylish. Stay warm and fashionable with this trendy oversized hoodie.', 'https://sa.hm.com/assets/styles/HNM/17493970/ce2a05141ecd434083aa5c2f9bac83b4e01896c1/1/image-thumb__5598249__product_zoom_medium_606x504/ce2a05141ecd434083aa5c2f9bac83b4e01896c1.jpg', '400.99'),
(13, 'Rib-knit midi dress', 'This Rib-knit midi dress is perfect for any occasion. Its stylish design and comfortable fit make it a must-have addition to your wardrobe. Available in multiple colors and sizes, you can find the perfect fit for you. Add this dress to your bag now and elevate your style!', 'https://sa.hm.com/assets/styles/HNM/17227163/48d61cecc4e230c914ea6c119b5c9a0c395c28c7/1/image-thumb__5324284__product_zoom_medium_606x504/48d61cecc4e230c914ea6c119b5c9a0c395c28c7.jpg', '290.99'),
(14, 'Brushed-inside leggings', 'Introducing our new Brushed-inside leggings, perfect for comfort and style. These shoes feature a spacious design that accommodates wider feet without compromising on fashion. Step out with confidence and enjoy a trendy look with these versatile joggers.', 'https://sa.hm.com/assets/styles/HNM/17381094/e77a10ad9d430d62ca0775acbdf8c6af5d1a515f/1/image-thumb__5461546__product_zoom_medium_606x504/e77a10ad9d430d62ca0775acbdf8c6af5d1a515f.jpg', '199.99'),
(15, 'Wide Leg paper bag jeans', 'These Wide Leg paper bag jeans are designed for both style and comfort. Made from high-quality fabric, they feature a relaxed fit and a flattering silhouette. Perfect for any occasion, these trousers can be dressed up or down to suit your personal style.', 'https://sa.hm.com/assets/styles/HNM/17493912/a111810f1a188ffc907c5e4cc950542ac47f27e8/1/image-thumb__5597094__product_zoom_medium_606x504/a111810f1a188ffc907c5e4cc950542ac47f27e8.jpg', '175.99'),
(16, 'Knitted dress', 'This cozy Knitted dress is perfect for chilly weather. It features a soft fabric and a stylish design that will keep you warm and fashionable. Pair it with your favorite jeans for a casual yet trendy look.', 'https://sa.hm.com/assets/styles/HNM/17352332/c1a23ebfb5909d289fd1b0caa26afadabeb9dff2/1/image-thumb__5441095__product_zoom_medium_606x504/c1a23ebfb5909d289fd1b0caa26afadabeb9dff2.jpg', '340.99'),
(17, 'Jacket', 'This jacket is made of high-quality materials and designed for both style and comfort. It features a modern cut and a sleek design that will elevate any outfit. The jacket is perfect for both casual and formal occasions, and it\'s suitable for all seasons. Stay fashionable and cozy with this versatile piece!', 'https://rino-pelle.com/cdn/shop/files/Kuna.7002312_Blanc-Stone_00.jpg?v=1694536149&width=533', '199.99'),
(18, 'Cardigan and Blouse', 'A stylish and comfortable cardigan and blouse set that is perfect for both casual and formal occasions. The cardigan features a soft and cozy fabric, while the blouse is made from a lightweight and breathable material. The set can be easily paired with jeans, skirts, or trousers for a versatile and trendy look.', 'https://rino-pelle.com/cdn/shop/files/Raiko.7002311_Lurex-Tile_00.jpg?v=1694536166&width=1066', '399.99'),
(19, 'Jacket', 'This jacket is made of high-quality materials and designed for both style and comfort. It features a modern cut and a sleek design that will elevate any outfit. The jacket is perfect for both casual and formal occasions, and it\'s suitable for all seasons. Stay fashionable and cozy with this versatile piece!', 'https://rino-pelle.com/cdn/shop/files/Kolle.7002312_Wildlime_00.jpg?v=1694536203', '249.99'),
(20, 'Dinty sweater', 'A cozy and stylish sweater for any occasion. Made from high-quality materials, the Dinty sweater offers both comfort and fashion. Its soft fabric keeps you warm during chilly days, while the trendy design adds a touch of elegance to your outfit. Choose your preferred color and size to make a fashion statement.', 'https://rino-pelle.com/cdn/shop/files/Dinty.7002312_Sage_00.jpg?v=1694536235&width=533', '299.99'),
(21, 'Coat', 'This stylish coat is perfect for all seasons. It features a comfortable fit and high-quality. materials to keep you warm and stylish. Available in various colors and sizes.</p>', 'https://rino-pelle.com/cdn/shop/files/Jojo.7002310_cookie_00_84bcb524-a570-4f67-9d58-7a1418209ec8.jpg?v=1696369738&width=533', '244.99'),
(22, 'Dress sweater', 'This dress sweater is made from high-quality materials and features a stylish design that is perfect for any occasion. It offers a comfortable fit and is available in multiple colors and sizes. Choose your preferred color and size from the options below and add this trendy dress sweater to your wardrobe today!', 'https://rino-pelle.com/cdn/shop/files/Janou.7002312_blanc_02.jpg?v=1692020914&width=720', '239.99'),
(23, 'https://rino-pelle.com/cdn/shop/files/Railey.7002311_black-white-strokes_01.jpg?v=1689863147', 'This blouse is made from high-quality fabric and features a trendy design that is perfect for any occasion. Its comfortable fit and stylish details make it a must-have addition to your wardrobe. Pair it with your favorite jeans or a skirt for a chic and fashionable look.', 'https://rino-pelle.com/cdn/shop/files/Railey.7002311_black-white-strokes_01.jpg?v=1689863147', '399.99'),
(24, 'Cardigan and Blouse', 'A stylish and comfortable cardigan and blouse set that is perfect for both casual and formal occasions. The cardigan features a soft and cozy fabric, while the blouse is made from a lightweight and breathable material. The set can be easily paired with jeans, skirts, or trousers for a versatile and trendy look.', 'https://rino-pelle.com/cdn/shop/files/Kelson.7002313_blanc_01.jpg?v=1699538482', '249.99'),
(25, 'Dinty sweater', 'A cozy and stylish sweater for any occasion. Made from high-quality materials, the Dinty sweater offers both comfort and fashion. Its soft fabric keeps you warm during chilly days, while the trendy design adds a touch of elegance to your outfit. Choose your preferred color and size to make a fashion statement.', 'https://rino-pelle.com/cdn/shop/files/Kai.7002311_taupe_01.jpg?v=1690444543', '299.99'),
(26, 'Coat', 'This stylish coat is perfect for all seasons. It features a comfortable fit and high-quality materials to keep you warm and stylish. Available in various colors and sizes.', 'https://rino-pelle.com/cdn/shop/files/Jix.7002310_caramel_02.jpg?v=1692190646&width=720', '244.99'),
(27, 'Coat', 'This stylish coat is perfect for all seasons. It features a comfortable fit and high-quality materials to keep you warm and stylish. Available in various colors and sizes', 'https://rino-pelle.com/cdn/shop/files/Jing.7002310_stone_01.jpg?v=1692020553', '229.99'),
(28, 'Dress sweater', 'This dress sweater is made from high-quality materials and features a stylish design that is perfect for any occasion. It offers a comfortable fit and is available in multiple colors and sizes. Choose your preferred color and size from the options below and add this trendy dress sweater to your wardrobe today!', 'https://rino-pelle.com/cdn/shop/files/tenzil.7002311_dove_01.jpg?v=1690796356', '239.99'),
(29, 'Coat', 'This stylish coat is perfect for all seasons. It features a comfortable fit and high-quality materials to keep you warm and stylish. Available in various colors and sizes', 'https://rino-pelle.com/cdn/shop/files/Saami.7002310_Blanc_00.jpg?v=1694536174&width=1066', '232.99'),
(30, '', '', '', '0.00'),
(30, 'Jacket', 'This jacket is made of high-quality materials and designed for both style and comfort. It features a modern cut and a sleek design that will elevate any outfit.\r\nThe jacket is perfect for both casual and formal occasions, and it\'s suitable for all seasons. Stay fashionable and cozy with this versatile piece!', 'https://rino-pelle.com/cdn/shop/files/Jalia.7002310_sage_01.jpg?v=1695634539', '199.99'),
(31, 'Mako trousers', 'The Mako trousers are stylish and comfortable, made from high-quality materials. With multiple pockets and a versatile design, they are perfect for various occasions, whether a day at the office or a casual outing.', 'https://rino-pelle.com/cdn/shop/files/Mako-worn-by-Anna-apost_c1448421-41d2-43ee-8a83-ca063dfff72e.jpg?v=1701369048', '232.99'),
(32, 'Hoodie', 'A comfortable and stylish hoodie for any occasion. Made from high-quality materials, this hoodie is perfect for keeping you warm and cozy during the colder months. Available in multiple colors and sizes to suit your preference.', 'https://sa.hm.com/assets/styles/HNM/17060159/5a93471d488478036cf88b4638d0fdf470514185/1/image-thumb__5132184__product_listing/5a93471d488478036cf88b4638d0fdf470514185.jpg', '199.99'),
(33, 'Sweatshirt', 'This stylish sweatshirt is made from high-quality cotton fabric, providing comfort and durability. It features a trendy design with a relaxed fit, perfect for casual wear. Available in various colors and sizes.', 'https://sa.hm.com/assets/styles/HNM/17318431/0d9e90a04245b1d01c12390cc744f1ca634d0158/1/image-thumb__5400305__product_listing/0d9e90a04245b1d01c12390cc744f1ca634d0158.jpg', '199.99'),
(34, 'Sweatshirt', 'This stylish sweatshirt is made from high-quality cotton fabric, providing comfort and durability.It features a trendy design with a relaxed fit, perfect for casual wear. Available in various colors and sizes.', 'https://sa.hm.com/assets/styles/HNM/17262215/ca7f5984665d8549d060d4cd4f702d0030508204/1/image-thumb__5344878__product_listing/ca7f5984665d8549d060d4cd4f702d0030508204.jpg', '244.99'),
(35, 'Jacket', 'This stylish jacket is perfect for any season. It is made from high-quality materials, ensuring durability and comfort. The jacket features a modern design with a sleek fit. Stay warm and fashionable with this must-have addition to your wardrobe.', 'https://sa.hm.com/assets/styles/HNM/16979179/73af33e79c37c01d78edd23639561b1f423ee95e/1/image-thumb__5038753__product_listing/73af33e79c37c01d78edd23639561b1f423ee95e.jpg', '229.99'),
(36, 'Hoodie', 'A comfortable and stylish hoodie for any occasion. Made from high-quality materials, this hoodie is perfect for keeping you warm and cozy during the colder months. Available in multiple colors and sizes to suit your preference.', 'https://s3.eu-west-1.amazonaws.com/als-ecom-pimshm-prod-s3/assets/HNM/16761414/0974a5419ae5f2851a8d6a3627caae491556e74f/1/0974a5419ae5f2851a8d6a3627caae491556e74f.jpg', '199.99'),
(37, 'Sweatshirt', 'This stylish sweatshirt is made from high-quality cotton fabric, providing comfort and durability. It features a trendy design with a relaxed fit, perfect for casual wear. Available in various colors and sizes.', 'https://sa.hm.com/assets/styles/HNM/17008634/7ca674c098304ac89851d1b1fe28bcdd2f7cd574/1/image-thumb__5085211__product_zoom_medium_606x504/7ca674c098304ac89851d1b1fe28bcdd2f7cd574.jpg', '199.99'),
(38, 'Sweatshirt', 'his stylish sweatshirt is made from high-quality cotton fabric, providing comfort and durability. It features a trendy design with a relaxed fit, perfect for casual wear. Available in various colors and sizes.', 'https://s3.eu-west-1.amazonaws.com/als-ecom-pimshm-prod-s3/assets/HNM/17005572/c78b468f8c6d6009b2fe4591234a8caa1740c74b/1/c78b468f8c6d6009b2fe4591234a8caa1740c74b.jpg', '249.99'),
(39, 'Jacket', 'This stylish jacket is perfect for any season. It is made from high-quality materials, ensuring durability and comfort. The jacket features a modern design with a sleek fit. Stay warm and fashionable with this must-have addition to your wardrobe.', 'https://sa.hm.com/assets/styles/HNM/16961609/eb9177a3bfc193a34c78291b578c80846ff7551c/1/image-thumb__5029398__product_zoom_medium_606x504/eb9177a3bfc193a34c78291b578c80846ff7551c.jpg', '299.99'),
(40, 'Jacket', 'This stylish jacket is perfect for any season. It is made from high-quality materials, ensuring durability and comfort. The jacket features a modern design with a sleek fit. Stay warm and fashionable with this must-have addition to your wardrobe.', 'https://sa.hm.com/assets/styles/HNM/15690837/bf2573d3128296510d43299336fd4025c116c62e/1/image-thumb__4500660__product_zoom_medium_606x504/bf2573d3128296510d43299336fd4025c116c62e.jpg', '229.99'),
(41, 'Hoodie', 'A comfortable and stylish hoodie for any occasion. Made from high-quality materials, this hoodie is perfect for keeping you warm and cozy during the colder months. Available in multiple colors and sizes to suit your preference.', 'https://s3.eu-west-1.amazonaws.com/als-ecom-pimshm-prod-s3/assets/HNM/16740915/c6ea0b990966fbc77d7a7ff680e0d1248644d285/1/c6ea0b990966fbc77d7a7ff680e0d1248644d285.jpg', '239.99'),
(42, 'Jacket', 'This stylish jacket is perfect for any season. It is made from high-quality materials, ensuring durability and comfort. The jacket features a modern design with a sleek fit. Stay warm and fashionable with this must-have addition to your wardrobe.', 'https://sa.hm.com/assets/styles/HNM/17149786/8220a1df8319f5a119cf41e8285afe1528733d86/1/image-thumb__5220578__product_listing/8220a1df8319f5a119cf41e8285afe1528733d86.jpg', '232.99'),
(43, 'Sweatshirt', 'This stylish sweatshirt is made from high-quality cotton fabric, providing comfort and durability. It features a trendy design with a relaxed fit, perfect for casual wear. Available in various colors and sizes.', 'https://sa.hm.com/assets/styles/HNM/15037712/2a6cf577538cfefb1e618d506c66e7bc118869b1/1/image-thumb__4235616__product_listing/2a6cf577538cfefb1e618d506c66e7bc118869b1.jpg', '249.99'),
(44, 'Sweatshirt', 'Stay cozy and stylish with this sweatshirt. Made from high-quality materials, it offers comfort and warmth. The classic design makes it versatile for various occasions. Upgrade your wardrobe with this must-have piece.', 'https://sa.hm.com/assets/styles/HNM/17172624/cbeadccf24e45a6bc1706138bde7b9ffc8dfec98/1/image-thumb__5242400__product_zoom_large_800x800/cbeadccf24e45a6bc1706138bde7b9ffc8dfec98.jpg', '190.99'),
(45, 'Printed joggers', 'Introducing our new wide jogger shoes, perfect for comfort and style. These shoes feature a spacious design that accommodates wider feet without compromising on fashion. Step out with confidence and enjoy a trendy look with these versatile joggers.', 'https://sa.hm.com/assets/styles/HNM/16985807/48f3dc710cd3d11ec983e91b0b7d435c87868b94/1/image-thumb__5051316__product_zoom_large_800x800/48f3dc710cd3d11ec983e91b0b7d435c87868b94.jpg', '199.99'),
(46, 'Neck top', 'These printed Neck top are perfect for a casual and stylish look. Made with comfortable fabric, they feature a trendy design that adds a pop of color to your outfit. Pair it with jeans or shorts for a cool and effortless look.', 'https://sa.hm.com/assets/styles/HNM/17208227/b6df9636354a91f59431b3f2190efb3edc558dba/1/image-thumb__5290582__product_zoom_large_800x800/b6df9636354a91f59431b3f2190efb3edc558dba.jpg', '100.99'),
(47, 'Jacket', 'This stylish jacket is designed for both comfort and fashion. It features a sleek design with high-quality materials that offer warmth and durability. Perfect for any occasion, this jacket is a must-have in your wardrobe.', 'https://sa.hm.com/assets/styles/HNM/16705145/9dc95845f437f311dbcc9d1a6cbb46242bbc198b/1/image-thumb__4864489__product_zoom_large_800x800/9dc95845f437f311dbcc9d1a6cbb46242bbc198b.jpg', '300.99'),
(48, 'Trousers', 'These trousers are crafted from high-quality fabric, offering both style and comfort. They feature a modern design with a slim fit and are available in multiple sizes and colors. Perfect for any occasion, these trousers will elevate your wardrobe.', 'https://sa.hm.com/assets/styles/HNM/17312083/c4a4ab3844db7a36860ae8b6525d3f87f15ea949/1/image-thumb__5372109__product_zoom_large_800x800/c4a4ab3844db7a36860ae8b6525d3f87f15ea949.jpg', '200.99'),
(49, 'Sweatshirt', 'Stay cozy and stylish with this sweatshirt. Made from high-quality materials, it offers comfort and warmth. The classic design makes it versatile for various occasions. Upgrade your wardrobe with this must-have piece.', 'https://sa.hm.com/assets/styles/HNM/17182863/ada85612f9c465a709a632da8b7f84a8d5a0cf70/1/image-thumb__5258032__product_zoom_medium_606x504/ada85612f9c465a709a632da8b7f84a8d5a0cf70.jpg', '190.00'),
(50, 'Hooded top', 'These Hooded top are perfect for a casual and stylish look. Made with comfortable fabric, they feature a trendy design that adds a pop of color to your outfit. Pair it with jeans or shorts for a cool and effortless look.', 'https://sa.hm.com/assets/styles/HNM/17083315/13a6ebc820120f1b1aa684cb2a164fc826f3dc45/1/image-thumb__5149643__product_listing/13a6ebc820120f1b1aa684cb2a164fc826f3dc45.jpg', '100.99'),
(51, 'Trousers', 'These trousers are crafted from high-quality fabric, offering both style and comfort. They feature a modern design with a slim fit and are available in multiple sizes and colors. Perfect for any occasion, these trousers will elevate your wardrobe.', 'https://s3.eu-west-1.amazonaws.com/als-ecom-pimshm-prod-s3/assets/HNM/16028629/e32b52bccf7fddaf93a6a4299b9e2aee376c83fe/1/e32b52bccf7fddaf93a6a4299b9e2aee376c83fe.jpg', '200.99'),
(52, 'Denim dungarees', 'Tay stylish and comfortable with our denim dungarees. Made from high-quality denim fabric, these dungarees feature a relaxed fit and adjustable straps for a customizable fit. Whether you\'re running errands or hanging out with friends, these dungarees are a versatile addition to your wardrobe. Pair them with a  t-shirt or blouse for a trendy and effortless look.', 'https://sa.hm.com/assets/styles/HNM/16894919/e4c174bfbbe570b67f83a729f7e73e162cdf0aed/1/image-thumb__4970420__product_zoom_large_800x800/e4c174bfbbe570b67f83a729f7e73e162cdf0aed.jpg', '190.99'),
(53, 'Sweatshirt', 'This comfortable sweatshirt is perfect for staying cozy during colder days. Made with high-quality materials, it provides warmth and style. Available in multiple colors and sizes, it\'s a versatile addition to your wardrobe.', 'https://sa.hm.com/assets/styles/HNM/17035320/bb3099adfd0ce03ea1fe3b7e7e134f482efed4f0/1/image-thumb__5106472__product_zoom_medium_606x504/bb3099adfd0ce03ea1fe3b7e7e134f482efed4f0.jpg', '199.99'),
(54, 'jersey top', 'These jersey top are perfect for a casual and stylish look. Made with comfortable fabric, they feature a trendy design that adds a pop of color to your outfit. Pair it with jeans or shorts for a cool and effortless look.', 'https://sa.hm.com/assets/styles/HNM/16979225/9b9899bd5ab265956816f0f465d4e516791ab5be/1/image-thumb__5039668__product_listing/9b9899bd5ab265956816f0f465d4e516791ab5be.jpg', '100.99'),
(55, 'Sweatshirt', 'This comfortable and stylish sweatshirt is a perfect addition to your wardrobe. Made with high-quality materials, it offers a cozy fit and a trendy design. Stay warm and fashionable with this sweatshirt.', 'https://sa.hm.com/assets/styles/HNM/17410114/9b24af1e8acd1a1a6b798ae2abfc3fde7ba07c70/1/image-thumb__5482980__product_zoom_medium_606x504/9b24af1e8acd1a1a6b798ae2abfc3fde7ba07c70.jpg', '400.99');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `Id` int(11) NOT NULL,
  `email` varchar(100) NOT NULL,
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`Id`, `email`, `username`, `password`) VALUES
(0, 'rrr4444@hotmail.com', 'rahaf', '$2y$10$qufUMzyd5zF554YcJL595ulsAbojMNIwnIg5oUPQ14euAzmwdTjHG');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
