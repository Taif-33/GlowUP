<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>GlowUp - Your Fashion Destination</title>

    <link rel="stylesheet" type="text/css" href="style3.css">
    <script src="script3.js"></script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
        crossorigin="anonymous"></script>
</head>

<body>
    
<!-- Header Section -->
<header>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <!-- Container for navigation elements -->
        <div class="container">
            <!-- Brand/logo -->
            <a class="navbar-brand" href="#">
                <h4>
                    <em>GlowUp</em>
                </h4>
            </a>
            <!-- Toggler button for small screens -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Navigation links -->
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="Women.php">Women</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Men.php">Men</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="girls.php">Kids girls</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="boys.php">Kids boys</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="ShoppingBag.php">
                            <img src="https://th.bing.com/th/id/OIP.SlPKG8oNNf7REyoldslkIQHaHa?rs=1&pid=ImgDetMain"
                                alt="Shopping Bag" width="20" height="20"> Shopping Bag
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>
    



<!-- Main Content Section -->
<div id="shopify-section-template--19799974773067__264455d4-f47a-4ee6-93df-555e68d05dbf" class="shopify-section">
    <!-- Main Banner Section -->
    <section class="section-main-banner firstbnr_cls section-id-template--19799974773067__264455d4-f47a-4ee6-93df-555e68d05dbf">
        <!-- Row for banner content -->
        <div class="row b_imgdatarow">
            <!-- Banner content snippet -->
            <div class="snippet-main-banner bnr_template--19799974773067__264455d4-f47a-4ee6-93df-555e68d05dbf full-width">
                <!-- Video container -->
                <div class="video-container">
                    <!-- Video element -->
                    <video playsinline="true" preload="metadata" muted="muted" loop="loop" autoplay="autoplay"
                        class="fullvideo"
                        poster="//rino-pelle.com/cdn/shop/files/preview_images/4a1df70d39124f5c89199bdb769a96ab.thumbnail.0000000000_small.jpg?v=1694531101">
                        <source
                            src="https://cdn.shopify.com/videos/c/vp/4a1df70d39124f5c89199bdb769a96ab/4a1df70d39124f5c89199bdb769a96ab.HD-1080p-7.2Mbps-18326668.mp4"
                            type="video/mp4">
                        <img
                            src="//rino-pelle.com/cdn/shop/files/preview_images/4a1df70d39124f5c89199bdb769a96ab.thumbnail.0000000000_small.jpg?v=1694531101">
                    </video>
                    <!-- Video content overlay -->
                        <div class="video-content">
                            <h1>
                                <em>GlowUp</em>
                            </h1>
                            <h3>
                                <em>Discover Your Style</em>
                            </h3>
                            <p>
                                <em>Get inspired by our curated collection of fashionable clothing</em>
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>


    <h2>
        <em>Clothes Women</em>
    </h2>
    <div class="product-container">
        <div class="product">
            <img src="https://rino-pelle.com/cdn/shop/files/Kuna.7002312_Blanc-Stone_00.jpg?v=1694536149&width=533"
                alt="Product 1">
            <div class="product-info">
                <h4>Jacket</h4>
                <p class="price">$199.99</p>
                <button id="add-to-bag-1">ADD TO BAG</button>
            </div>
        </div>

        <div class="product">
            <img src="https://rino-pelle.com/cdn/shop/files/Raiko.7002311_Lurex-Tile_00.jpg?v=1694536166&width=1066"
                alt="Product 2">
            <div class="product-info">
                <h4>cardigan & Blouse</h4>
                <p class="price">$399.99</p>
                <button id="add-to-bag-2">ADD TO BAG</button>
            </div>
        </div>

        <div class="product">
            <img src="https://rino-pelle.com/cdn/shop/files/Kolle.7002312_Wildlime_00.jpg?v=1694536203" alt="Product 3">
            <div class="product-info">
                <h4>Jacket</h4>
                <p class="price">$249.99</p>
                <button id="add-to-bag-3">ADD TO BAG</button>
            </div>
        </div>

        <div class="product">
            <img src="https://rino-pelle.com/cdn/shop/files/Dinty.7002312_Sage_00.jpg?v=1694536235&width=533"
                alt="Product 4">
            <div class="product-info">
                <h4>Dinty sweater</h4>
                <p class="price">$299.99</p>
                <button id="add-to-bag-4">ADD TO BAG</button>
            </div>
        </div>

        <div class="product">
            <img src="https://rino-pelle.com/cdn/shop/files/Jojo.7002310_cookie_00_84bcb524-a570-4f67-9d58-7a1418209ec8.jpg?v=1696369738&width=533"
                alt="Product 5">
            <div class="product-info">
                <h4>Coat</h4>
                <p class="price">$244.99</p>
                <button id="add-to-bag-5">ADD TO BAG</button>
            </div>
        </div>

        <div class="product">
            <img src="p6.jpg" alt="Product 6">
            <div class="product-info">
                <h4>Blouse</h4>
                <p class="price">$229.99</p>
                <button id="add-to-bag-6">ADD TO BAG</button>
            </div>
        </div>

        <div class="product">
            <img src="https://rino-pelle.com/cdn/shop/files/tenzil.7002311_dove_01.jpg?v=1690796356" alt="Product 7">
            <div class="product-info">
                <h4>sweater dress</h4>
                <p class="price">$239.99</p>
                <button id="add-to-bag-7">ADD TO BAG</button>
            </div>
        </div>

    </div>


    <h2>
        <em>Clothes Men</em>
    </h2>
    <div class="product-container">
        <div class="product">
            <img src="https://s3.eu-west-1.amazonaws.com/als-ecom-pimshm-prod-s3/assets/HNM/16761414/0974a5419ae5f2851a8d6a3627caae491556e74f/1/0974a5419ae5f2851a8d6a3627caae491556e74f.jpg"
                alt="Product 1">
            <div class="product-info">
                <h4>Hoodie</h4>
                <p class="price">$199.99</p>
                <button id="add-to-bag-1">ADD TO BAG</button>
            </div>
        </div>

        <div class="product">
            <img src="https://sa.hm.com/assets/styles/HNM/17008634/7ca674c098304ac89851d1b1fe28bcdd2f7cd574/1/image-thumb__5085211__product_zoom_medium_606x504/7ca674c098304ac89851d1b1fe28bcdd2f7cd574.jpg"
                alt="Product 2">
            <div class="product-info">
                <h4>Sweatshirt</h4>
                <p class="price">$199.99</p>
                <button id="add-to-bag-2">ADD TO BAG</button>
            </div>
        </div>

        <div class="product">
            <img src="https://s3.eu-west-1.amazonaws.com/als-ecom-pimshm-prod-s3/assets/HNM/17005572/c78b468f8c6d6009b2fe4591234a8caa1740c74b/1/c78b468f8c6d6009b2fe4591234a8caa1740c74b.jpg"
                alt="Product 3">
            <div class="product-info">
                <h4>Sweatshirt</h4>
                <p class="price">$249.99</p>
                <button id="add-to-bag-3">ADD TO BAG</button>
            </div>
        </div>

        <div class="product">
            <img src="https://sa.hm.com/assets/styles/HNM/16961609/eb9177a3bfc193a34c78291b578c80846ff7551c/1/image-thumb__5029398__product_zoom_medium_606x504/eb9177a3bfc193a34c78291b578c80846ff7551c.jpg"
                alt="Product 4">
            <div class="product-info">
                <h4>Jacket</h4>
                <p class="price">$299.99</p>
                <button id="add-to-bag-4">ADD TO BAG</button>
            </div>
        </div>

        <div class="product">
            <img src="https://sa.hm.com/assets/styles/HNM/16978959/662f816f0966df27b4c13ae7e75de23c027153df/1/image-thumb__5041949__product_zoom_medium_606x504/662f816f0966df27b4c13ae7e75de23c027153df.jpg"
                alt="Product 5">
            <div class="product-info">
                <h4>Sweatshirt</h4>
                <p class="price">$244.99</p>
                <button id="add-to-bag-5">ADD TO BAG</button>
            </div>
        </div>

        <div class="product">
            <img src="https://sa.hm.com/assets/styles/HNM/15690837/bf2573d3128296510d43299336fd4025c116c62e/1/image-thumb__4500660__product_zoom_medium_606x504/bf2573d3128296510d43299336fd4025c116c62e.jpg"
                alt="Product 6">
            <div class="product-info">
                <h4>Jacket</h4>
                <p class="price">$229.99</p>
                <button id="add-to-bag-6">ADD TO BAG</button>
            </div>
        </div>

        <div class="product">
            <img src="https://s3.eu-west-1.amazonaws.com/als-ecom-pimshm-prod-s3/assets/HNM/16740915/c6ea0b990966fbc77d7a7ff680e0d1248644d285/1/c6ea0b990966fbc77d7a7ff680e0d1248644d285.jpg"
                alt="Product 7">
            <div class="product-info">
                <h4>Hoodie</h4>
                <p class="price">$239.99</p>
                <button id="add-to-bag-7">ADD TO BAG</button>
            </div>
        </div>

    </div>


    <h2>
        <em>Kids girls</em>
    </h2>
    <div class="product-container">
        <div class="product">
            <img src="https://sa.hm.com/assets/styles/HNM/17312146/41c2ebefd4b1f49d151711a235c01fbf280df98c/1/image-thumb__5373004__product_zoom_large_800x800/41c2ebefd4b1f49d151711a235c01fbf280df98c.jpg"
                alt="Product 1">
            <div class="product-info">
                <h4>Lace-detail blouse</h4>
                <p class="price">$199.99</p>
                <button id="add-to-bag-1">ADD TO BAG</button>
            </div>
        </div>

        <div class="product">
            <img src="https://sa.hm.com/assets/styles/HNM/17083883/ec8fba1e1794acd04eec9d8c1e13b35ab0cdd019/1/image-thumb__5152775__product_zoom_large_800x800/ec8fba1e1794acd04eec9d8c1e13b35ab0cdd019.jpg"
                alt="Product 2">
            <div class="product-info">
                <h4>Wide joggers</h4>
                <p class="price">$200.99</p>
                <button id="add-to-bag-2">ADD TO BAG</button>
            </div>
        </div>

        <div class="product">
            <img src="https://sa.hm.com/assets/styles/HNM/16961534/cea5dd8b0de0fbb8de60e06a066e2f0f82ff705b/1/image-thumb__5030000__product_zoom_large_800x800/cea5dd8b0de0fbb8de60e06a066e2f0f82ff705b.jpg"
                alt="Product 3">
            <div class="product-info">
                <h4>Wide trousers</h4>
                <p class="price">$175.99</p>
                <button id="add-to-bag-3">ADD TO BAG</button>
            </div>
        </div>

        <div class="product">
            <img src="https://sa.hm.com/assets/styles/HNM/17217850/5337978774292c9a39cfadce3415cf90d607ce37/1/image-thumb__5318197__product_zoom_large_800x800/5337978774292c9a39cfadce3415cf90d607ce37.jpg"
                alt="Product 4">
            <div class="product-info">
                <h4>Dinty sweater</h4>
                <p class="price">$340.99</p>
                <button id="add-to-bag-4">ADD TO BAG</button>
            </div>
        </div>

        <div class="product">
            <img src="https://sa.hm.com/assets/styles/HNM/17061693/0bea7207ee683567b4b74db23ac36c92b3cf1452/1/image-thumb__5137649__product_zoom_large_800x800/0bea7207ee683567b4b74db23ac36c92b3cf1452.jpg"
                alt="Product 5">
            <div class="product-info">
                <h4>Oversized hoodie </h4>
                <p class="price">$400.99</p>
                <button id="add-to-bag-5">ADD TO BAG</button>
            </div>
        </div>

        <div class="product">
            <img src=" https://sa.hm.com/assets/styles/HNM/17207119/6bfd58731b11cf67c86d9d91a5a16c584def7438/1/image-thumb__5291982__product_zoom_large_800x800/6bfd58731b11cf67c86d9d91a5a16c584def7438.jpg"
                alt="Product 6">
            <div class="product-info">
                <h4>Ribbed dress </h4>
                <p class="price">$290.99</p>
                <button id="add-to-bag-6">ADD TO BAG</button>
            </div>
        </div>

        <div class="product">
            <img src="https://sa.hm.com/assets/styles/HNM/17035452/dc8f7a3545514ea65ad732d4476e417c5dd99931/1/image-thumb__5108788__product_zoom_large_800x800/dc8f7a3545514ea65ad732d4476e417c5dd99931.jpg"
                alt="Product 7">
            <div class="product-info">
                <h4>dress </h4>
                <p class="price">$280.99</p>
                <button id="add-to-bag-7">ADD TO BAG</button>
            </div>
        </div>

    </div>


    <h2>
        <em>Kids boys</em>
    </h2>
    <div class="product-container">
        <div class="product">
            <img src="https://sa.hm.com/assets/styles/HNM/17172624/cbeadccf24e45a6bc1706138bde7b9ffc8dfec98/1/image-thumb__5242400__product_zoom_large_800x800/cbeadccf24e45a6bc1706138bde7b9ffc8dfec98.jpg"
                alt="Product 1">
            <div class="product-info">
                <h4> sweatshirt</h4>
                <p class="price">$190.99</p>
                <button id="add-to-bag-1">ADD TO BAG</button>
            </div>
        </div>
        <div class="product">
            <img src="https://sa.hm.com/assets/styles/HNM/16985807/48f3dc710cd3d11ec983e91b0b7d435c87868b94/1/image-thumb__5051316__product_zoom_large_800x800/48f3dc710cd3d11ec983e91b0b7d435c87868b94.jpg"
                alt="Product 2">
            <div class="product-info">
                <h4>Printed joggers</h4>
                <p class="price">$199.99</p>
                <button id="add-to-bag-2">ADD TO BAG</button>
            </div>
        </div>

        <div class="product">
            <img src="https://sa.hm.com/assets/styles/HNM/17208227/b6df9636354a91f59431b3f2190efb3edc558dba/1/image-thumb__5290582__product_zoom_large_800x800/b6df9636354a91f59431b3f2190efb3edc558dba.jpg"
                alt="Product 4">
            <div class="product-info">
                <h4>neck top </h4>
                <p class="price">$100.99</p>
                <button id="add-to-bag-4">ADD TO BAG</button>
            </div>
        </div>

        <div class="product">
            <img src="https://sa.hm.com/assets/styles/HNM/17185803/50496553c5fef988c0ccadfaffa54563bd444c77/1/image-thumb__5262482__product_zoom_large_800x800/50496553c5fef988c0ccadfaffa54563bd444c77.jpg"
                alt="Product 5">
            <div class="product-info">
                <h4>sweatshirt</h4>
                <p class="price">$400.99</p>
                <button id="add-to-bag-5">ADD TO BAG</button>
            </div>
        </div>

        <div class="product">
            <img src="https://sa.hm.com/assets/styles/HNM/16705145/9dc95845f437f311dbcc9d1a6cbb46242bbc198b/1/image-thumb__4864489__product_zoom_large_800x800/9dc95845f437f311dbcc9d1a6cbb46242bbc198b.jpg"
                alt="Product 6">
            <div class="product-info">
                <h4>jacket</h4>
                <p class="price">$300.99</p>
                <button id="add-to-bag-6">ADD TO BAG</button>
            </div>
        </div>

        <div class="product">
            <img src="https://sa.hm.com/assets/styles/HNM/17312083/c4a4ab3844db7a36860ae8b6525d3f87f15ea949/1/image-thumb__5372109__product_zoom_large_800x800/c4a4ab3844db7a36860ae8b6525d3f87f15ea949.jpg"
                alt="Product 7">
            <div class="product-info">
                <h4>trousers </h4>
                <p class="price">$200.99</p>
                <button id="add-to-bag-7">ADD TO BAG</button>
            </div>
        </div>

        <div class="product">
            <img src="https://sa.hm.com/assets/styles/HNM/16894919/e4c174bfbbe570b67f83a729f7e73e162cdf0aed/1/image-thumb__4970420__product_zoom_large_800x800/e4c174bfbbe570b67f83a729f7e73e162cdf0aed.jpg"
                alt="Product 7">
            <div class="product-info">
                <h4>Denim dungarees </h4>
                <p class="price">$199.99</p>
                <button id="add-to-bag-7">ADD TO BAG</button>
            </div>
        </div>

    </div>





    
<!-- Divider Section -->
<div class="b-example-divider">
    <!-- Container for footer -->
    <div class="container">
        <!-- Footer Section -->
        <footer class="py-5">
             <!-- Row for footer content -->
            <div class="row">
                <!-- Company Info Section -->
                <div class="col-6 col-md-2 mb-3-expand-md ">
                    <h5>Company info</h5>
                    <ul class="nav flex-column">
                        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">About GlowUp</a>
                        </li>
                        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Fashion
                                Blogger</a></li>
                        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Features</a></li>

                    </ul>
                </div>

                <!-- Help Section -->
                <div class="col-6 col-md-2 mb-3-expand-md">
                    <h5>Help </h5>
                    <ul class="nav flex-column">
                        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Shipping Info</a>
                        </li>
                        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Returns</a></li>
                        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Refund</a></li>

                    </ul>
                </div>

                <!-- Customer Care Section -->
                <div class="col-6 col-md-2 mb-3-expand-md">
                    <h5>customer care</h5>
                    <ul class="nav flex-column">
                        <li class="nav-item mb-2"><a href="/contact Us/5.3/"
                                class="nav-link p-0 text-body-secondary">Contact Us</a>
                        </li>
                        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Payment
                                Method</a></li>
                        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Bonus Point</a>
                        </li>
                    </ul>
                </div>

                <!-- Logo and Form Section -->
                <div class="col-md-5 offset-md-1 mb-3-expand-md">
                    <form>
                    <img src="logo.jpg" alt="GlowUp logo" class="logo">
                    <div class="d-flex flex-column flex-sm-row w-100 gap-2">
                    </div>
                    </form>
                </div>
            </div>

            <div class="d-flex flex-column flex-sm-row justify-content-between py-4 my-4 border-top-expand-sm">
                <div class="container">
                    <!-- Footer content -->
                    <p>&copy; 2023 GlowUp, All rights reserved.</p>
                     <!-- Social media icons -->
                    <i class="bi bi-instagram">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                            class="bi bi-instagram" viewBox="0 0 16 16">
                            <path
                                d="M8 0C5.829 0 5.556.01 4.703.048 3.85.088 3.269.222 2.76.42a3.917 3.917 0 0 0-1.417.923A3.927 3.927 0 0 0 .42 2.76C.222 3.268.087 3.85.048 4.7.01 5.555 0 5.827 0 8.001c0 2.172.01 2.444.048 3.297.04.852.174 1.433.372 1.942.205.526.478.972.923 1.417.444.445.89.719 1.416.923.51.198 1.09.333 1.942.372C5.555 15.99 5.827 16 8 16s2.444-.01 3.298-.048c.851-.04 1.434-.174 1.943-.372a3.916 3.916 0 0 0 1.416-.923c.445-.445.718-.891.923-1.417.197-.509.332-1.09.372-1.942C15.99 10.445 16 10.173 16 8s-.01-2.445-.048-3.299c-.04-.851-.175-1.433-.372-1.941a3.926 3.926 0 0 0-.923-1.417A3.911 3.911 0 0 0 13.24.42c-.51-.198-1.092-.333-1.943-.372C10.443.01 10.172 0 7.998 0h.003zm-.717 1.442h.718c2.136 0 2.389.007 3.232.046.78.035 1.204.166 1.486.275.373.145.64.319.92.599.28.28.453.546.598.92.11.281.24.705.275 1.485.039.843.047 1.096.047 3.231s-.008 2.389-.047 3.232c-.035.78-.166 1.203-.275 1.485a2.47 2.47 0 0 1-.599.919c-.28.28-.546.453-.92.598-.28.11-.704.24-1.485.276-.843.038-1.096.047-3.232.047s-2.39-.009-3.233-.047c-.78-.036-1.203-.166-1.485-.276a2.478 2.478 0 0 1-.92-.598 2.48 2.48 0 0 1-.6-.92c-.109-.281-.24-.705-.275-1.485-.038-.843-.046-1.096-.046-3.233 0-2.136.008-2.388.046-3.231.036-.78.166-1.204.276-1.486.145-.373.319-.64.599-.92.28-.28.546-.453.92-.598.282-.11.705-.24 1.485-.276.738-.034 1.024-.044 2.515-.045v.002zm4.988 1.328a.96.96 0 1 0 0 1.92.96.96 0 0 0 0-1.92zm-4.27 1.122a4.109 4.109 0 1 0 0 8.217 4.109 4.109 0 0 0 0-8.217zm0 1.441a2.667 2.667 0 1 1 0 5.334 2.667 2.667 0 0 1 0-5.334z" />
                        </svg>
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                            class="bi bi-whatsapp" viewBox="0 0 16 16">
                            <path
                                d="M13.601 2.326A7.854 7.854 0 0 0 7.994 0C3.627 0 .068 3.558.064 7.926c0 1.399.366 2.76 1.057 3.965L0 16l4.204-1.102a7.933 7.933 0 0 0 3.79.965h.004c4.368 0 7.926-3.558 7.93-7.93A7.898 7.898 0 0 0 13.6 2.326zM7.994 14.521a6.573 6.573 0 0 1-3.356-.92l-.24-.144-2.494.654.666-2.433-.156-.251a6.56 6.56 0 0 1-1.007-3.505c0-3.626 2.957-6.584 6.591-6.584a6.56 6.56 0 0 1 4.66 1.931 6.557 6.557 0 0 1 1.928 4.66c-.004 3.639-2.961 6.592-6.592 6.592zm3.615-4.934c-.197-.099-1.17-.578-1.353-.646-.182-.065-.315-.099-.445.099-.133.197-.513.646-.627.775-.114.133-.232.148-.43.05-.197-.1-.836-.308-1.592-.985-.59-.525-.985-1.175-1.103-1.372-.114-.198-.011-.304.088-.403.087-.088.197-.232.296-.346.1-.114.133-.198.198-.33.065-.134.034-.248-.015-.347-.05-.099-.445-1.076-.612-1.47-.16-.389-.323-.335-.445-.34-.114-.007-.247-.007-.38-.007a.729.729 0 0 0-.529.247c-.182.198-.691.677-.691 1.654 0 .977.71 1.916.81 2.049.098.133 1.394 2.132 3.383 2.992.47.205.84.326 1.129.418.475.152.904.129 1.246.08.38-.058 1.171-.48 1.338-.943.164-.464.164-.86.114-.943-.049-.084-.182-.133-.38-.232z" />
                        </svg>
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                            class="bi bi-facebook" viewBox="0 0 16 16">
                            <path
                                d="M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0-.002 3.603-.002 8.05c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951z" />
                        </svg>
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                            class="bi bi-twitter-x" viewBox="0 0 16 16">
                            <path
                                d="M12.6.75h2.454l-5.36 6.142L16 15.25h-4.937l-3.867-5.07-4.425 5.07H.316l5.733-6.57L0 .75h5.063l3.495 4.633L12.601.75Zm-.86 13.028h1.36L4.323 2.145H2.865l8.875 11.633Z" />
                        </svg>
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                            class="bi bi-tiktok" viewBox="0 0 16 16">
                            <path
                                d="M9 0h1.98c.144.715.54 1.617 1.235 2.512C12.895 3.389 13.797 4 15 4v2c-1.753 0-3.07-.814-4-1.829V11a5 5 0 1 1-5-5v2a3 3 0 1 0 3 3V0Z" />
                        </svg>
                        
                        <div>
                            <!-- Payment icons -->
                            <a class="text-decoration-none me-3" href="#"><img src="https://cdn.msaaq.com/assets/images/payments/applepay.svg" alt="Apple Pay" width="25" height="20"></a>
                            <a class="text-decoration-none me-3" href="#"><img src="https://cdn.msaaq.com/assets/images/payments/visa.svg" alt="Visa" width="25" height="20"></a>
                            <a class="text-decoration-none me-3" href="#"><img src="https://cdn.msaaq.com/assets/images/payments/master.svg" alt="Mastercard" width="25" height="20"></a>
                            <a class="text-decoration-none me-3" href="#"><img src="https://cdn.msaaq.com/assets/images/payments/mada.svg" alt="mada" width="25" height="20"></a>
                            <a class="text-decoration-none" href="#"><img src="https://www.annualgivingnetwork.com/wp-content/uploads/2018/04/iStock-1093968482-cropped-768x555.jpeg" alt="cash" width="25" height="20"></a>
                        </div>

                </div>
        </footer>
    </div>

    <div class="c-footer" title="back to top">
        <button id="backtotop">&#8593;</button>
    </div>

</body>

</html>