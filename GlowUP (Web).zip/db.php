<?php
$db_host = "localhost";
$db_user = "GlowUP"; // Replace with your database username
$db_pass = "Glow&UP123$"; // Replace with your database password
$db_database = 'glowup';

// Database connection
$conn = new mysqli($db_host, $db_user, $db_pass, $db_database);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
$result = $conn->query("SELECT * FROM cart");
if (!$result) {
    die("Error: " . $conn->error);
}