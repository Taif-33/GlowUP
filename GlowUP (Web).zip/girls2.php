<!DOCTYPE html>
<html>

<head>
    <title>GlowUp-Clothes Kids girls</title>

    <link rel="stylesheet" type="text/css" href="style4.css">
    <script src="script4.js"></script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>
<header>
<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
    <div class="container">
        <a class="navbar-brand" href="#">
            <h4>
                <em>GlowUp</em>
            </h4>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
            aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="Women.php">Women</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="Men.php">Men</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="girls.php">Kids girls</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="boys.php">Kids boys</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="ShoppingBag.php">
                        <img src="https://th.bing.com/th/id/OIP.SlPKG8oNNf7REyoldslkIQHaHa?rs=1&pid=ImgDetMain" alt="Shopping Bag" width="20" height="20"> Shopping Bag
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

</header>
    
    <div class="product-cards-container">

        <div class="product-card">
            <div class="shoe-details">
                <img src="https://sa.hm.com/assets/styles/HNM/17035452/dc8f7a3545514ea65ad732d4476e417c5dd99931/1/image-thumb__5108788__product_zoom_large_800x800/dc8f7a3545514ea65ad732d4476e417c5dd99931.jpg"
                    alt="Product 1">
                <span class="shoe-name">dress</span>
                <p>This dress is perfect for any occasion. It features a stylish design with a comfortable fit.<br />
                Made from high-quality materials, it is both fashionable and durable. Choose your preferred color and size from the options provided.</p>
                <div class="stars bx">
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bx-star"></i>
                </div>
            </div>

            <div class="color-size-price">
                <div class="color-option">
                    <span class="color">Color:</span>
                    <div class="circles">
                        <span class="circle beige active" id="beige"></span>
                        <span class="circle black" id="black"></span>
                        <span class="circle brown" id="brown"></span>
                    </div>
                </div>


                <div class="size-option">
                    <span class="size">Size:</span>
                    <div class="sizes">
                        <span class="size-option">5</span>
                        <span class="size-option">6</span>
                        <span class="size-option">7</span>
                        <span class="size-option">8</span>
                        <span class="size-option">9</span>
                        <span class="size-option">10</span>
                        <span class="size-option">11</span>
                        <span class="size-option">12</span>
                        <span class="size-option">13</span>
                        <span class="size-option">14</span>
                    </div>
                </div>

                <div class="price">
                    <span class="price_num">$200.99</span>
                </div>
            </div>

            <div class="button">
                <button class="add-to-bag">Add to Bag</button>
            </div>
        </div>


        <div class="product-card">
            <div class="shoe-details">
                <img src="https://sa.hm.com/assets/styles/HNM/17092474/1c3b78449bdbba180e0ec77479c3317273c6845b/1/image-thumb__5180945__product_listing/1c3b78449bdbba180e0ec77479c3317273c6845b.jpg"
                    alt="Product 2">
                <span class="shoe-name">Jacket</span>
                <p>This jacket is a stylish and versatile addition to your wardrobe. It features a modern design with a comfortable fit.<br />
                The high-quality material ensures durability and warmth, making it perfect for colder weather.<br />
                Whether you're going for a casual or a more dressed-up look, this jacket is sure to elevate your style.</p>
                <div class="stars bx">
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bx-star"></i>
                </div>
            </div>

            <div class="color-size-price">
                <div class="color-option">
                    <span class="color">Color:</span>
                    <div class="circles">
                        <span class="circle beige active" id="beige"></span>
                        <span class="circle black" id="black"></span>
                        <span class="circle brown" id="brown"></span>
                    </div>
                </div>
                <div class="size-option">
                    <span class="size">Size:</span>
                    <div class="sizes">
                        <span class="size-option">5</span>
                        <span class="size-option">6</span>
                        <span class="size-option">7</span>
                        <span class="size-option">8</span>
                        <span class="size-option">9</span>
                        <span class="size-option">10</span>
                        <span class="size-option">11</span>
                        <span class="size-option">12</span>
                        <span class="size-option">13</span>
                        <span class="size-option">14</span>
                    </div>
                </div>

                <div class="price">
                    <span class="price_num">$199.99</span>
                </div>
            </div>

            <div class="button">
                <button class="add-to-bag">Add to Bag</button>
            </div>
        </div>


        <div class="product-card">
            <div class="shoe-details">
                <img src="https://sa.hm.com/assets/styles/HNM/17015561/82ebe8e668116b953ea10522b256de83cd870a24/1/image-thumb__5090981__product_zoom_medium_606x504/82ebe8e668116b953ea10522b256de83cd870a24.jpg"
                    alt="Product 3">
                <span class="shoe-name">Wide Leg Low Jeans</span>
                <p>These Jeans are designed for both style and comfort. Made from high-quality fabric, they feature a relaxed fit and a flattering silhouette.<br />
                     Perfect for any occasion, these trousers can be dressed up or down to suit your personal style.<br />
                      Pair them with a blouse and heels for a sophisticated look, or dress them down with a t-shirt and sneakers for a more casual ensemble.</p>
                <div class="stars bx">
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bx-star"></i>
                </div>
            </div>

            <div class="color-size-price">
                <div class="color-option">
                    <span class="color">Color:</span>
                    <div class="circles">
                        <span class="circle beige active" id="beige"></span>
                        <span class="circle black" id="black"></span>
                        <span class="circle brown" id="brown"></span>
                    </div>
                </div>


                <div class="size-option">
                    <span class="size">Size:</span>
                    <div class="sizes">
                        <span class="size-option">5</span>
                        <span class="size-option">6</span>
                        <span class="size-option">7</span>
                        <span class="size-option">8</span>
                        <span class="size-option">9</span>
                        <span class="size-option">10</span>
                        <span class="size-option">11</span>
                        <span class="size-option">12</span>
                        <span class="size-option">13</span>
                        <span class="size-option">14</span>
                    </div>
                </div>

                <div class="price">
                    <span class="price_num">$175.99</span>
                </div>
            </div>

            <div class="button">
                <button class="add-to-bag">Add to Bag</button>
            </div>
        </div>


        <div class="product-card">
            <div class="shoe-details">
                <img src="https://sa.hm.com/assets/styles/HNM/17183150/c95cd99e5db3818b3fea5fdfb43d055d327e7d95/1/image-thumb__5257960__product_zoom_medium_606x504/c95cd99e5db3818b3fea5fdfb43d055d327e7d95.jpg"
                    alt="Product 4">
                <span class="shoe-name">Jacquard-knit jumper</span>
                <p>This cozy  jumper is perfect for chilly weather. It features a soft fabric and a stylish design that will keep you warm and fashionable.<br />
                      Pair it with your favorite jeans for a casual yet trendy look.</p>
                <div class="stars bx">
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bx-star"></i>
                </div>
            </div>
            <div class="color-size-price">
                <div class="color-option">
                    <span class="color">Color:</span>
                    <div class="circles">
                        <span class="circle beige active" id="beige"></span>
                        <span class="circle black" id="black"></span>
                        <span class="circle brown" id="brown"></span>
                    </div>
                </div>


                <div class="size-option">
                    <span class="size">Size:</span>
                    <div class="sizes">
                        <span class="size-option">5</span>
                        <span class="size-option">6</span>
                        <span class="size-option">7</span>
                        <span class="size-option">8</span>
                        <span class="size-option">9</span>
                        <span class="size-option">10</span>
                        <span class="size-option">11</span>
                        <span class="size-option">12</span>
                        <span class="size-option">13</span>
                        <span class="size-option">14</span>
                    </div>
                </div>

                <div class="price">
                    <span class="price_num">$340.99</span>
                </div>
            </div>

            <div class="button">
                <button class="add-to-bag">Add to Bag</button>
            </div>
        </div>


        <div class="product-card">
            <div class="shoe-details">
                <img src="https://sa.hm.com/assets/styles/HNM/17493970/ce2a05141ecd434083aa5c2f9bac83b4e01896c1/1/image-thumb__5598249__product_zoom_medium_606x504/ce2a05141ecd434083aa5c2f9bac83b4e01896c1.jpg"
                    alt="Product 5">
                <span class="shoe-name">Oversized hoodie</span>
                <p>This oversized hoodie is made from soft and comfortable fabric, perfect for casual and cozy wear. It features a relaxed fit and a kangaroo pocket for added convenience.<br />
                     Available in multiple colors and sizes, this hoodie is versatile and stylish. Stay warm and fashionable with this trendy oversized hoodie.</p>
                <div class="stars bx">
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bx-star"></i>
                </div>
            </div>

            <div class="color-size-price">
                <div class="color-option">
                    <span class="color">Color:</span>
                    <div class="circles">
                        <span class="circle beige active" id="beige"></span>
                        <span class="circle black" id="black"></span>
                        <span class="circle brown" id="brown"></span>
                    </div>
                </div>


                <div class="size-option">
                    <span class="size">Size:</span>
                    <div class="sizes">
                        <span class="size-option">5</span>
                        <span class="size-option">6</span>
                        <span class="size-option">7</span>
                        <span class="size-option">8</span>
                        <span class="size-option">9</span>
                        <span class="size-option">10</span>
                        <span class="size-option">11</span>
                        <span class="size-option">12</span>
                        <span class="size-option">13</span>
                        <span class="size-option">14</span>
                    </div>
                </div>

                <div class="price">
                    <span class="price_num">$400.99</span>
                </div>
            </div>

            <div class="button">
                <button class="add-to-bag">Add to Bag</button>
            </div>
        </div>


        <div class="product-card">
            <div class="shoe-details">
                <img src="https://sa.hm.com/assets/styles/HNM/17227163/48d61cecc4e230c914ea6c119b5c9a0c395c28c7/1/image-thumb__5324284__product_zoom_medium_606x504/48d61cecc4e230c914ea6c119b5c9a0c395c28c7.jpg"
                 alt="Product 6">
                <span class="shoe-name">Rib-knit midi dress</span>
                <p>This Rib-knit midi dress is perfect for any occasion. Its stylish design and comfortable fit make it a must-have addition to your wardrobe.<br />
                     Available in multiple colors and sizes, you can find the perfect fit for you. Add this dress to your bag now and elevate your style!</p>
                <div class="stars bx">
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bx-star"></i>
                </div>
            </div>
            <div class="color-size-price">
                <div class="color-option">
                    <span class="color">Color:</span>
                    <div class="circles">
                        <span class="circle beige active" id="beige"></span>
                        <span class="circle black" id="black"></span>
                        <span class="circle brown" id="brown"></span>
                    </div>
                </div>


                <div class="size-option">
                    <span class="size">Size:</span>
                    <div class="sizes">
                        <span class="size-option">5</span>
                        <span class="size-option">6</span>
                        <span class="size-option">7</span>
                        <span class="size-option">8</span>
                        <span class="size-option">9</span>
                        <span class="size-option">10</span>
                        <span class="size-option">11</span>
                        <span class="size-option">12</span>
                        <span class="size-option">13</span>
                        <span class="size-option">14</span>
                    </div>
                </div>

                <div class="price">
                    <span class="price_num">$290.99</span>
                </div>
            </div>

            <div class="button">
                <button class="add-to-bag">Add to Bag</button>
            </div>
        </div>
    </div>

    <div class="pagination-container">
        <a href="girls.php" class="pagination-item">
            <img src="https://f.nooncdn.com/s/app/com/sivvi/design-system/icons-v2/chevron-back.svg" alt="chevronBack"
                class="pagination-icon" loading="eager">
        </a>

        <a href="girls.php" class="pagination-item">1</a>
        <a href="girls2.php" class="pagination-item">2</a>
        <span class="ellipsis">...</span>
        <a href="girls3.php" class="pagination-item">3</a>

        <a href="girls3.php" class="pagination-item">
            <img src="https://f.nooncdn.com/s/app/com/sivvi/design-system/icons-v2/chevron-forward.svg"
                alt="chevronForward" class="pagination-icon" loading="eager">
        </a>
    </div>

    <div class="c-footer" title="back to top">
        <button id="backtotop">&#8593;</button>
    </div>
    
</body>

</html>