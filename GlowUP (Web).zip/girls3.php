<!DOCTYPE html>
<html>

<head>
    <title>GlowUp-Clothes Kids girls</title>

    <link rel="stylesheet" type="text/css" href="style4.css">
    <script src="script4.js"></script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>
<header>
<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
    <div class="container">
        <a class="navbar-brand" href="#">
            <h4>
                <em>GlowUp</em>
            </h4>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
            aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="Women.php">Women</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="Men.php">Men</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="girls.php">Kids girls</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="boys.php">Kids boys</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="ShoppingBag.php">
                        <img src="https://th.bing.com/th/id/OIP.SlPKG8oNNf7REyoldslkIQHaHa?rs=1&pid=ImgDetMain" alt="Shopping Bag" width="20" height="20"> Shopping Bag
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

</header>
    
    <div class="product-cards-container">

        <div class="product-card">
            <div class="shoe-details">
                <img src="https://sa.hm.com/assets/styles/HNM/17226480/7f1498b7564ed38f1aed1b9274dc62b0b4735440/1/image-thumb__5325342__product_zoom_medium_606x504/7f1498b7564ed38f1aed1b9274dc62b0b4735440.jpg"
                    alt="Product 1">
                <span class="shoe-name">Tie-front blouse</span>
                <p>ThisTie-front blouse is a versatile addition to your wardrobe.<br />
                     It features intricate lace detailing and a stylish design that can be dressed up or down.<br />
                      Made from high-quality materials, it offers both comfort and style.<br />
                     Pair it with jeans or a skirt for a chic and trendy look.</p>
                <div class="stars bx">
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bx-star"></i>
                </div>
            </div>

            <div class="color-size-price">
                <div class="color-option">
                    <span class="color">Color:</span>
                    <div class="circles">
                        <span class="circle beige active" id="beige"></span>
                        <span class="circle black" id="black"></span>
                        <span class="circle brown" id="brown"></span>
                    </div>
                </div>


                <div class="size-option">
                    <span class="size">Size:</span>
                    <div class="sizes">
                        <span class="size-option">5</span>
                        <span class="size-option">6</span>
                        <span class="size-option">7</span>
                        <span class="size-option">8</span>
                        <span class="size-option">9</span>
                        <span class="size-option">10</span>
                        <span class="size-option">11</span>
                        <span class="size-option">12</span>
                        <span class="size-option">13</span>
                        <span class="size-option">14</span>
                    </div>
                </div>

                <div class="price">
                    <span class="price_num">$200.99</span>
                </div>
            </div>

            <div class="button">
                <button class="add-to-bag">Add to Bag</button>
            </div>
        </div>


        <div class="product-card">
            <div class="shoe-details">
                <img src="https://sa.hm.com/assets/styles/HNM/17381094/e77a10ad9d430d62ca0775acbdf8c6af5d1a515f/1/image-thumb__5461546__product_zoom_medium_606x504/e77a10ad9d430d62ca0775acbdf8c6af5d1a515f.jpg"
                    alt="Product 2">
                <span class="shoe-name">Brushed-inside leggings</span>
                <p>Introducing our new Brushed-inside leggings, perfect for comfort and style.<br />
                     These shoes feature a spacious design that accommodates wider feet without compromising on fashion.<br />
                     Step out with confidence and enjoy a trendy look with these versatile joggers.</p>
                <div class="stars bx">
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bx-star"></i>
                </div>
            </div>

            <div class="color-size-price">
                <div class="color-option">
                    <span class="color">Color:</span>
                    <div class="circles">
                        <span class="circle beige active" id="beige"></span>
                        <span class="circle black" id="black"></span>
                        <span class="circle brown" id="brown"></span>
                    </div>
                </div>
                <div class="size-option">
                    <span class="size">Size:</span>
                    <div class="sizes">
                        <span class="size-option">5</span>
                        <span class="size-option">6</span>
                        <span class="size-option">7</span>
                        <span class="size-option">8</span>
                        <span class="size-option">9</span>
                        <span class="size-option">10</span>
                        <span class="size-option">11</span>
                        <span class="size-option">12</span>
                        <span class="size-option">13</span>
                        <span class="size-option">14</span>
                    </div>
                </div>

                <div class="price">
                    <span class="price_num">$199.99</span>
                </div>
            </div>

            <div class="button">
                <button class="add-to-bag">Add to Bag</button>
            </div>
        </div>


        <div class="product-card">
            <div class="shoe-details">
                <img src="https://sa.hm.com/assets/styles/HNM/17493912/a111810f1a188ffc907c5e4cc950542ac47f27e8/1/image-thumb__5597094__product_zoom_medium_606x504/a111810f1a188ffc907c5e4cc950542ac47f27e8.jpg"
                    alt="Product 3">
                <span class="shoe-name">Wide Leg paper bag jeans</span>
                <p>These Wide Leg paper bag jeans are designed for both style and comfort. Made from high-quality fabric, they feature a relaxed fit and a flattering silhouette.<br />
                     Perfect for any occasion, these trousers can be dressed up or down to suit your personal style.</p>
                <div class="stars bx">
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bx-star"></i>
                </div>
            </div>

            <div class="color-size-price">
                <div class="color-option">
                    <span class="color">Color:</span>
                    <div class="circles">
                        <span class="circle beige active" id="beige"></span>
                        <span class="circle black" id="black"></span>
                        <span class="circle brown" id="brown"></span>
                    </div>
                </div>


                <div class="size-option">
                    <span class="size">Size:</span>
                    <div class="sizes">
                        <span class="size-option">5</span>
                        <span class="size-option">6</span>
                        <span class="size-option">7</span>
                        <span class="size-option">8</span>
                        <span class="size-option">9</span>
                        <span class="size-option">10</span>
                        <span class="size-option">11</span>
                        <span class="size-option">12</span>
                        <span class="size-option">13</span>
                        <span class="size-option">14</span>
                    </div>
                </div>

                <div class="price">
                    <span class="price_num">$175.99</span>
                </div>
            </div>

            <div class="button">
                <button class="add-to-bag">Add to Bag</button>
            </div>
        </div>


        <div class="product-card">
            <div class="shoe-details">
                <img src="https://sa.hm.com/assets/styles/HNM/17352332/c1a23ebfb5909d289fd1b0caa26afadabeb9dff2/1/image-thumb__5441095__product_zoom_medium_606x504/c1a23ebfb5909d289fd1b0caa26afadabeb9dff2.jpg"
                    alt="Product 4">
                <span class="shoe-name">Knitted dress</span>
                <p>This cozy Knitted dress is perfect for chilly weather. It features a soft fabric and a stylish design that will keep you warm and fashionable.<br />
                      Pair it with your favorite jeans for a casual yet trendy look.</p>
                <div class="stars bx">
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bx-star"></i>
                </div>
            </div>
            <div class="color-size-price">
                <div class="color-option">
                    <span class="color">Color:</span>
                    <div class="circles">
                        <span class="circle beige active" id="beige"></span>
                        <span class="circle black" id="black"></span>
                        <span class="circle brown" id="brown"></span>
                    </div>
                </div>


                <div class="size-option">
                    <span class="size">Size:</span>
                    <div class="sizes">
                        <span class="size-option">5</span>
                        <span class="size-option">6</span>
                        <span class="size-option">7</span>
                        <span class="size-option">8</span>
                        <span class="size-option">9</span>
                        <span class="size-option">10</span>
                        <span class="size-option">11</span>
                        <span class="size-option">12</span>
                        <span class="size-option">13</span>
                        <span class="size-option">14</span>
                    </div>
                </div>

                <div class="price">
                    <span class="price_num">$340.99</span>
                </div>
            </div>

            <div class="button">
                <button class="add-to-bag">Add to Bag</button>
            </div>
        </div>
    </div>

    <div class="pagination-container">
        <a href="girls2.php" class="pagination-item">
            <img src="https://f.nooncdn.com/s/app/com/sivvi/design-system/icons-v2/chevron-back.svg" alt="chevronBack"
                class="pagination-icon" loading="eager">
        </a>

        <a href="girls.php" class="pagination-item">1</a>
        <a href="girls2.php" class="pagination-item">2</a>
        <span class="ellipsis">...</span>
        <a href="girls3.php" class="pagination-item">3</a>

        <a href="boys.php" class="pagination-item">
            <img src="https://f.nooncdn.com/s/app/com/sivvi/design-system/icons-v2/chevron-forward.svg"
                alt="chevronForward" class="pagination-icon" loading="eager">
        </a>
    </div>

    <div class="c-footer" title="back to top">
        <button id="backtotop">&#8593;</button>
    </div>
    
</body>

</html>