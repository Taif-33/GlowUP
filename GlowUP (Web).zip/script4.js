document.addEventListener('DOMContentLoaded', function () {
    const productCards = document.querySelectorAll('.product-card');
    const backToTopButton = document.getElementById('backtotop');

    productCards.forEach(productCard => {
        const colorCircles = productCard.querySelectorAll('.color-option .circle');
        const sizeOptions = productCard.querySelectorAll('.size-option .size-option');
        const addToBagButton = productCard.querySelector('.add-to-bag');
        const shoeName = productCard.querySelector('.shoe-name');
        const price = productCard.querySelector('.price_num');
        const selectedInfo = document.createElement('div');
        selectedInfo.className = 'selected-info';

        colorCircles.forEach(circle => {
            circle.addEventListener('click', () => {
                colorCircles.forEach(circle => {
                    circle.classList.remove('active');
                });
                circle.classList.add('active');
                updateSelectedInfo();
            });
        });

        sizeOptions.forEach(option => {
            option.addEventListener('click', () => {
                sizeOptions.forEach(option => {
                    option.classList.remove('active');
                });
                option.classList.add('active');
                updateSelectedInfo();
            });
        });

        addToBagButton.addEventListener('click', function () {
            const selectedColor = productCard.querySelector('.color-option .circle.active');
            const selectedSize = productCard.querySelector('.size-option .size-option.active');

            if (selectedColor && selectedSize) {
                const color = selectedColor.getAttribute('id');
                const size = selectedSize.innerText;
                const shoe = shoeName.textContent;
                const productPrice = parseFloat(price.textContent.replace('$', '')); // Update this line

                // Add the selected product to the shopping bag
                addToShoppingBag(shoe, color, size, productPrice);

                

                // Redirect to the shopping bag page
                window.location.href = 'ShoppingBag.php';
            } else {
                console.log('Please select a color and size.');
            }
        });

        function updateSelectedInfo() {
            const selectedColor = productCard.querySelector('.color-option .circle.active');
            const selectedSize = productCard.querySelector('.size-option .size-option.active');

            if (selectedColor && selectedSize) {
                const color = selectedColor.getAttribute('id');
                const size = selectedSize.innerText;
                const price = priceElement ? priceElement.textContent : 'N/A'; // Check if the price element exists
                selectedInfo.textContent = `Selected: Color: ${color}, Size: ${size} , Price: ${price}`;
            } else {
                selectedInfo.textContent = '';
            }
        }

        productCard.appendChild(selectedInfo);
    });

    window.addEventListener('scroll', function () {
        if (window.scrollY > 200) {
            document.body.classList.add('scrolled');
        } else {
            document.body.classList.remove('scrolled');
        }
    });

    backToTopButton.addEventListener('click', function () {
        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    });
    function addToShoppingBag(productName, color, size, productPrice) {
        // Create a FormData object to send data in the request body
        const formData = new FormData();
        formData.append('productName', productName);
        formData.append('productColor', color);
        formData.append('productSize', size);
        formData.append('productPrice', productPrice);
    
        // Use the Fetch API to send a POST request to addToShoppingBag.php
        fetch('addToShoppingBag.php', {
            method: 'POST',
            body: formData,
        })
        .then(response => response.json())
        .then(data => {
            // Handle the response as needed
            console.log(data);
            // Redirect to the shopping bag page if the product is added successfully
            window.location.href = 'ShoppingBag.php';
        })
        .catch(error => {
            console.error('Error:', error);
        });
    }
    
});