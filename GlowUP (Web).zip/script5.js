// script5.js

function updateCartTotals() {
    const quantityElements = document.querySelectorAll('.quantity');
    const priceElements = document.querySelectorAll('.price_num');
    const subtotalElements = document.querySelectorAll('.subtotal');
    let total = 0;

    quantityElements.forEach((quantityElement, index) => {
        const quantity = parseInt(quantityElement.textContent);
        const price = parseFloat(priceElements[index].textContent.replace('$', ''));
        const subtotal = quantity * price;
        total += subtotal;

        // Update the subtotal element
        subtotalElements[index].textContent = `$${subtotal.toFixed(2)}`;
    });
}

// Add an event listener for updates to the cart
window.addEventListener('cartUpdated', updateCartTotals);

