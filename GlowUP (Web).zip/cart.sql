CREATE TABLE cart (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    color VARCHAR(50),
    Size VARCHAR(20),
    price DECIMAL(10, 2) NOT NULL,
    quantity INT NOT NULL
)

