<!DOCTYPE html>
<html>

<head>
    <title>GlowUp-Clothes Men</title>

    <link rel="stylesheet" type="text/css" href="style4.css">
    <script src="script4.js"></script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>
<header>
<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
    <div class="container">
        <a class="navbar-brand" href="#">
            <h4>
                <em>GlowUp</em>
            </h4>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
            aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="Women.php">Women</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="Men.php">Men</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="girls.php">Kids girls</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="boys.php">Kids boys</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="ShoppingBag.php">
                        <img src="https://th.bing.com/th/id/OIP.SlPKG8oNNf7REyoldslkIQHaHa?rs=1&pid=ImgDetMain" alt="Shopping Bag" width="20" height="20"> Shopping Bag
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

</header>
    
    <div class="product-cards-container">

        <div class="product-card">
            <div class="shoe-details">
                <img src="https://sa.hm.com/assets/styles/HNM/15037712/2a6cf577538cfefb1e618d506c66e7bc118869b1/1/image-thumb__4235616__product_listing/2a6cf577538cfefb1e618d506c66e7bc118869b1.jpg"
                    alt="Product 1">
                <span class="shoe-name">Sweatshirt</span>
                <p>This stylish sweatshirt is made from high-quality cotton fabric, providing comfort and durability.<br />
                    It features a trendy design with a relaxed fit, perfect for casual wear. Available in various colors and sizes.</p>
                <div class="stars bx">
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bx-star"></i>
                </div>
            </div>

            <div class="color-size-price">
                <div class="color-option">
                    <span class="color">Color:</span>
                    <div class="circles">
                        <span class="circle beige active" id="beige"></span>
                        <span class="circle black" id="black"></span>
                        <span class="circle brown" id="brown"></span>
                    </div>
                </div>


                <div class="size-option">
                    <span class="size">Size:</span>
                    <div class="sizes">
                        <span class="size-option">XS</span>
                        <span class="size-option">S</span>
                        <span class="size-option">M</span>
                        <span class="size-option">L</span>
                        <span class="size-option">XL</span>
                    </div>
                </div>

                <div class="price">
                    <span class="price_num">$249.99</span>
                </div>
            </div>

            <div class="button">
                <button class="add-to-bag">Add to Bag</button>
            </div>
        </div>


        <div class="product-card">
            <div class="shoe-details">
                <img src="https://sa.hm.com/assets/styles/HNM/17035612/a26cc219d8bc9ed1c8906d0230c9d26661ced218/1/image-thumb__5103501__product_listing/a26cc219d8bc9ed1c8906d0230c9d26661ced218.jpg"
                    alt="Product 2">
                <span class="shoe-name">Jacket</span>
                <p>This stylish jacket is perfect for any season. It is made from high-quality materials, ensuring durability and comfort.<br />
                     The jacket features a modern design with a sleek fit. Stay warm and fashionable with this must-have addition to your wardrobe.</p>
                <div class="stars bx">
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bx-star"></i>
                </div>
            </div>
            <div class="color-size-price">
                <div class="color-option">
                    <span class="color">Color:</span>
                    <div class="circles">
                        <span class="circle beige active" id="beige"></span>
                        <span class="circle black" id="black"></span>
                        <span class="circle brown" id="brown"></span>
                    </div>
                </div>


                <div class="size-option">
                    <span class="size">Size:</span>
                    <div class="sizes">
                        <span class="size-option">XS</span>
                        <span class="size-option">S</span>
                        <span class="size-option">M</span>
                        <span class="size-option">L</span>
                        <span class="size-option">XL</span>
                    </div>
                </div>

                <div class="price">
                    <span class="price_num">$299.99</span>
                </div>
            </div>

            <div class="button">
                <button class="add-to-bag">Add to Bag</button>
            </div>
        </div>

        <div class="product-card">
            <div class="shoe-details">
                <img src="https://s3.eu-west-1.amazonaws.com/als-ecom-pimshm-prod-s3/assets/HNM/16740915/c6ea0b990966fbc77d7a7ff680e0d1248644d285/1/c6ea0b990966fbc77d7a7ff680e0d1248644d285.jpg"
                    alt="Product 3">
                <span class="shoe-name">Hoodie</span>
                <p>A comfortable and stylish hoodie for any occasion. Made from high-quality materials, this hoodie is perfect for keeping you warm and cozy during the colder months.<br />
                    Available in multiple colors and sizes to suit your preference.</p>
                <div class="stars bx">
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bx-star"></i>
                </div>
            </div>

            <div class="color-size-price">
                <div class="color-option">
                    <span class="color">Color:</span>
                    <div class="circles">
                        <span class="circle beige active" id="beige"></span>
                        <span class="circle black" id="black"></span>
                        <span class="circle brown" id="brown"></span>
                    </div>
                </div>


                <div class="size-option">
                    <span class="size">Size:</span>
                    <div class="sizes">
                        <span class="size-option">XS</span>
                        <span class="size-option">S</span>
                        <span class="size-option">M</span>
                        <span class="size-option">L</span>
                        <span class="size-option">XL</span>
                    </div>
                </div>

                <div class="price">
                    <span class="price_num">$239.99</span>
                </div>
            </div>

            <div class="button">
                <button class="add-to-bag">Add to Bag</button>
            </div>
        </div>


        <div class="product-card">
            <div class="shoe-details">
                <img src="https://sa.hm.com/assets/styles/HNM/17149786/8220a1df8319f5a119cf41e8285afe1528733d86/1/image-thumb__5220578__product_listing/8220a1df8319f5a119cf41e8285afe1528733d86.jpg"
                    alt="Product 4">
                    <span class="shoe-name">Jacket</span>
                <p>This stylish jacket is perfect for any season. It is made from high-quality materials, ensuring durability and comfort.<br />
                     The jacket features a modern design with a sleek fit. Stay warm and fashionable with this must-have addition to your wardrobe.</p>
                <div class="stars bx">
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bx-star"></i>
                </div>
            </div>

            <div class="color-size-price">
                <div class="color-option">
                    <span class="color">Color:</span>
                    <div class="circles">
                        <span class="circle beige active" id="beige"></span>
                        <span class="circle black" id="black"></span>
                        <span class="circle brown" id="brown"></span>
                    </div>
                </div>


                <div class="size-option">
                    <span class="size">Size:</span>
                    <div class="sizes">
                        <span class="size-option">XS</span>
                        <span class="size-option">S</span>
                        <span class="size-option">M</span>
                        <span class="size-option">L</span>
                        <span class="size-option">XL</span>
                    </div>
                </div>

                <div class="price">
                    <span class="price_num">$232.99</span>
                </div>
            </div>

            <div class="button">
                <button class="add-to-bag">Add to Bag</button>
            </div>
        </div>
    </div>

    <div class="pagination-container">
        <a href="Men2.php" class="pagination-item">
            <img src="https://f.nooncdn.com/s/app/com/sivvi/design-system/icons-v2/chevron-back.svg" alt="chevronBack"
                class="pagination-icon" loading="eager">
        </a>

        <a href="Men.php" class="pagination-item">1</a>
        <a href="Men2.php" class="pagination-item">2</a>
        <span class="ellipsis">...</span>
        <a href="Men3.php" class="pagination-item">3</a>

        <a href="girls.php" class="pagination-item">
            <img src="https://f.nooncdn.com/s/app/com/sivvi/design-system/icons-v2/chevron-forward.svg"
                alt="chevronForward" class="pagination-icon" loading="eager">
        </a>
    </div>

    <div class="c-footer" title="back to top">
        <button id="backtotop">&#8593;</button>
    </div>
    
</body>

</html>