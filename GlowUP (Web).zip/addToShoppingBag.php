<?php
session_start();
// Database connection
include('db.php');
function calculateTax($total, $taxRate = 0.10) {
    // Adjust the tax rate according to your requirements
    $tax = $total * $taxRate;
    return $tax;
}

function calculateTotal() {
    $total = 0;

    if (isset($_SESSION['cart']) && !empty($_SESSION['cart'])) {
        foreach ($_SESSION['cart'] as $product) {
            $total += $product['price'] * $product['quantity'];
        }
    }

    return $total;
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the product information from the AJAX request
    $productName = $_POST['productName'];
    $productColor = $_POST['productColor'];
    $productSize = $_POST['productSize'];
    $productPrice = $_POST['productPrice'];

    // Check if 'cart' session variable exists
    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = [];
    }

    // Generate a unique key for each product based on name, color, and size
    $productKey = "{$productName}_{$productColor}_{$productSize}";

    // Check if the product is already in the cart
    if (isset($_SESSION['cart'][$productKey])) {
        $_SESSION['cart'][$productKey]['quantity'] += 1; // Increment quantity if the product is already in the cart
    } else {
        // Add the product to the cart with an initial quantity of 1
        $_SESSION['cart'][$productKey] = [
            'name' => $productName,
            'color' => $productColor,
            'size' => $productSize,
            'price' => floatval($productPrice),
            'quantity' => 1,
        ];
         // Insert the product into the database
         $insertQuery = $conn->prepare("INSERT INTO cart (name, color, size, price, quantity) VALUES (?, ?, ?, ?, 1)");
        $insertQuery->bind_param("sssd", $productName, $productColor, $productSize, $productPrice);

        if (!$insertQuery->execute()) {
            die("Error inserting into the database: " . $conn->error);
        }

        $insertQuery->close();
    }

    // Calculate total, tax, and final total
    $total = calculateTotal();
    $taxRate = 0.10; // 10% tax rate (adjust as needed)
    $tax = calculateTax($total, $taxRate);
    $finalTotal = $total + $tax;

    // Send a response indicating success with updated cart information
    echo json_encode([
        'status' => 'success',
        'cart' => $_SESSION['cart'],
        'price' => floatval($productPrice),
        'total' => $total,
        'tax' => $tax,
    ]);
} else {
    // Handle errors or debug information here
}
?>