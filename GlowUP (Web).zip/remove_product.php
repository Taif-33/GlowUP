<?php
session_start();

if (isset($_GET['product_key'])) {
    $productKey = $_GET['product_key'];

    // Remove the selected product from the session
    unset($_SESSION['cart'][$productKey]);

    // Redirect back to the cart page
    header('Location: ShoppingBag.php');
    exit();
}
?>
