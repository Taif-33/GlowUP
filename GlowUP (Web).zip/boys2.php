<!DOCTYPE html>
<html>

<head>
    <title>GlowUp-Clothes Kids boys</title>

    <link rel="stylesheet" type="text/css" href="style4.css">
    <script src="script4.js"></script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>
<header>
<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
    <div class="container">
        <a class="navbar-brand" href="#">
            <h4>
                <em>GlowUp</em>
            </h4>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
            aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="Women.php">Women</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="Men.php">Men</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="girls.php">Kids girls</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="boys.php">Kids boys</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="ShoppingBag.php">
                        <img src="https://th.bing.com/th/id/OIP.SlPKG8oNNf7REyoldslkIQHaHa?rs=1&pid=ImgDetMain" alt="Shopping Bag" width="20" height="20"> Shopping Bag
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

</header>

    <div class="product-cards-container">

        <div class="product-card">
            <div class="shoe-details">
                <img src="https://sa.hm.com/assets/styles/HNM/17182863/ada85612f9c465a709a632da8b7f84a8d5a0cf70/1/image-thumb__5258032__product_zoom_medium_606x504/ada85612f9c465a709a632da8b7f84a8d5a0cf70.jpg"
                    alt="Product 1">
                <span class="shoe-name">Sweatshirt</span>
                <p>Stay cozy and stylish with this sweatshirt. Made from high-quality materials, it offers comfort and warmth.<br />
                         The classic design makes it versatile for various occasions. Upgrade your wardrobe with this must-have piece.</p>
                <div class="stars bx">
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bx-star"></i>
                </div>
            </div>

            <div class="color-size-price">
                <div class="color-option">
                    <span class="color">Color:</span>
                    <div class="circles">
                        <span class="circle beige active" id="beige"></span>
                        <span class="circle black" id="black"></span>
                        <span class="circle brown" id="brown"></span>
                    </div>
                </div>


                <div class="size-option">
                    <span class="size">Size:</span>
                    <div class="sizes">
                        <span class="size-option">3</span>
                        <span class="size-option">4</span>
                        <span class="size-option">5</span>
                        <span class="size-option">6</span>
                        <span class="size-option">7</span>
                        <span class="size-option">8</span>
                        <span class="size-option">9</span>
                        <span class="size-option">10</span>
                        <span class="size-option">11</span>
                        <span class="size-option">12</span>
                    </div>
                </div>

                <div class="price">
                    <span class="price_num">$190.99</span>
                </div>
            </div>

            <div class="button">
                <button class="add-to-bag">Add to Bag</button>
            </div>
        </div>


        <div class="product-card">
            <div class="shoe-details">
                <img src="https://sa.hm.com/assets/styles/HNM/16625115/380311bc440853353b96d1a37dd8fe69cc6bea7c/1/image-thumb__4842182__product_listing/380311bc440853353b96d1a37dd8fe69cc6bea7c.jpg"
                    alt="Product 2">
                <span class="shoe-name">Printed joggers</span>
                <p>Introducing our new wide jogger shoes, perfect for comfort and style.<br />
                         These shoes feature a spacious design that accommodates wider feet without compromising on fashion.<br />
                         Step out with confidence and enjoy a trendy look with these versatile joggers.</p>
                <div class="stars bx">
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bx-star"></i>
                </div>
            </div>

            <div class="color-size-price">
                <div class="color-option">
                    <span class="color">Color:</span>
                    <div class="circles">
                        <span class="circle beige active" id="beige"></span>
                        <span class="circle black" id="black"></span>
                        <span class="circle brown" id="brown"></span>
                    </div>
                </div>
                <div class="size-option">
                    <span class="size">Size:</span>
                    <div class="sizes">
                        <span class="size-option">3</span>
                        <span class="size-option">4</span>
                        <span class="size-option">5</span>
                        <span class="size-option">6</span>
                        <span class="size-option">7</span>
                        <span class="size-option">8</span>
                        <span class="size-option">9</span>
                        <span class="size-option">10</span>
                        <span class="size-option">11</span>
                        <span class="size-option">12</span>
                    </div>
                </div>

                <div class="price">
                    <span class="price_num">$199.99</span>
                </div>
            </div>

            <div class="button">
                <button class="add-to-bag">Add to Bag</button>
            </div>
        </div>


        <div class="product-card">
            <div class="shoe-details">
                <img src="https://sa.hm.com/assets/styles/HNM/17083315/13a6ebc820120f1b1aa684cb2a164fc826f3dc45/1/image-thumb__5149643__product_listing/13a6ebc820120f1b1aa684cb2a164fc826f3dc45.jpg"
                    alt="Product 3">
                <span class="shoe-name">Hooded top</span>
                <p>These Hooded top are perfect for a casual and stylish look. Made with comfortable fabric, they feature a trendy design that adds a pop of color to your outfit.<br />
                     Pair it with jeans or shorts for a cool and effortless look.</p>
                <div class="stars bx">
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bx-star"></i>
                </div>
            </div>

            <div class="color-size-price">
                <div class="color-option">
                    <span class="color">Color:</span>
                    <div class="circles">
                        <span class="circle beige active" id="beige"></span>
                        <span class="circle black" id="black"></span>
                        <span class="circle brown" id="brown"></span>
                    </div>
                </div>


                <div class="size-option">
                    <span class="size">Size:</span>
                    <div class="sizes">
                        <span class="size-option">3</span>
                        <span class="size-option">4</span>
                        <span class="size-option">5</span>
                        <span class="size-option">6</span>
                        <span class="size-option">7</span>
                        <span class="size-option">8</span>
                        <span class="size-option">9</span>
                        <span class="size-option">10</span>
                        <span class="size-option">11</span>
                        <span class="size-option">12</span>
                    </div>
                </div>

                <div class="price">
                    <span class="price_num">$100.99</span>
                </div>
            </div>

            <div class="button">
                <button class="add-to-bag">Add to Bag</button>
            </div>
        </div>


        <div class="product-card">
            <div class="shoe-details">
                <img src="https://sa.hm.com/assets/styles/HNM/17191767/ddd6b73301bd684d6eaea3f3e90e6dfba6f3881b/1/image-thumb__5269833__product_listing/ddd6b73301bd684d6eaea3f3e90e6dfba6f3881b.jpg"
                    alt="Product 4">
                <span class="shoe-name">Sweatshirt</span>
                <p>This comfortable and stylish sweatshirt is a perfect addition to your wardrobe.<br />
                     Made with high-quality materials, it offers a cozy fit and a trendy design. Stay warm and fashionable with this sweatshirt.</p>
                <div class="stars bx">
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bx-star"></i>
                </div>
            </div>
            <div class="color-size-price">
                <div class="color-option">
                    <span class="color">Color:</span>
                    <div class="circles">
                        <span class="circle beige active" id="beige"></span>
                        <span class="circle black" id="black"></span>
                        <span class="circle brown" id="brown"></span>
                    </div>
                </div>


                <div class="size-option">
                    <span class="size">Size:</span>
                    <div class="sizes">
                        <span class="size-option">3</span>
                        <span class="size-option">4</span>
                        <span class="size-option">5</span>
                        <span class="size-option">6</span>
                        <span class="size-option">7</span>
                        <span class="size-option">8</span>
                        <span class="size-option">9</span>
                        <span class="size-option">10</span>
                        <span class="size-option">11</span>
                        <span class="size-option">12</span>
                    </div>
                </div>

                <div class="price">
                    <span class="price_num">$400.99</span>
                </div>
            </div>

            <div class="button">
                <button class="add-to-bag">Add to Bag</button>
            </div>
        </div>


        <div class="product-card">
            <div class="shoe-details">
                <img src="https://sa.hm.com/assets/styles/HNM/17295023/c2297b97458ac55b1c5bdb3b3b102388ba8baafe/1/image-thumb__5367336__product_zoom_medium_606x504/c2297b97458ac55b1c5bdb3b3b102388ba8baafe.jpg"
                    alt="Product 5">
                <span class="shoe-name">Classic Jacket</span>
                <p>This stylish Classic jacket is designed for both comfort and fashion. It features a sleek design with high-quality materials that offer warmth and durability.<br />
                    Perfect for any occasion, this jacket is a must-have in your wardrobe.</p>
                <div class="stars bx">
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bx-star"></i>
                </div>
            </div>

            <div class="color-size-price">
                <div class="color-option">
                    <span class="color">Color:</span>
                    <div class="circles">
                        <span class="circle beige active" id="beige"></span>
                        <span class="circle black" id="black"></span>
                        <span class="circle brown" id="brown"></span>
                    </div>
                </div>


                <div class="size-option">
                    <span class="size">Size:</span>
                    <div class="sizes">
                        <span class="size-option">3</span>
                        <span class="size-option">4</span>
                        <span class="size-option">5</span>
                        <span class="size-option">6</span>
                        <span class="size-option">7</span>
                        <span class="size-option">8</span>
                        <span class="size-option">9</span>
                        <span class="size-option">10</span>
                        <span class="size-option">11</span>
                        <span class="size-option">12</span>
                    </div>
                </div>

                <div class="price">
                    <span class="price_num">$300.99</span>
                </div>
            </div>

            <div class="button">
                <button class="add-to-bag">Add to Bag</button>
            </div>
        </div>


        <div class="product-card">
            <div class="shoe-details">
                <img src="https://s3.eu-west-1.amazonaws.com/als-ecom-pimshm-prod-s3/assets/HNM/16028629/e32b52bccf7fddaf93a6a4299b9e2aee376c83fe/1/e32b52bccf7fddaf93a6a4299b9e2aee376c83fe.jpg"
                 alt="Product 6">
                <span class="shoe-name">Trousers</span>
                <p>These trousers are crafted from high-quality fabric, offering both style and comfort.<br />
                     They feature a modern design with a slim fit and are available in multiple sizes and colors. Perfect for any occasion, these trousers will elevate your wardrobe.</p>
                <div class="stars bx">
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bx-star"></i>
                </div>
            </div>
            <div class="color-size-price">
                <div class="color-option">
                    <span class="color">Color:</span>
                    <div class="circles">
                        <span class="circle beige active" id="beige"></span>
                        <span class="circle black" id="black"></span>
                        <span class="circle brown" id="brown"></span>
                    </div>
                </div>


                <div class="size-option">
                    <span class="size">Size:</span>
                    <div class="sizes">
                        <span class="size-option">3</span>
                        <span class="size-option">4</span>
                        <span class="size-option">5</span>
                        <span class="size-option">6</span>
                        <span class="size-option">7</span>
                        <span class="size-option">8</span>
                        <span class="size-option">9</span>
                        <span class="size-option">10</span>
                        <span class="size-option">11</span>
                        <span class="size-option">12</span>
                    </div>
                </div>

                <div class="price">
                    <span class="price_num">$200.99</span>
                </div>
            </div>

            <div class="button">
                <button class="add-to-bag">Add to Bag</button>
            </div>
        </div>
    </div>

    <div class="pagination-container">
        <a href="boys.php" class="pagination-item">
            <img src="https://f.nooncdn.com/s/app/com/sivvi/design-system/icons-v2/chevron-back.svg" alt="chevronBack"
                class="pagination-icon" loading="eager">
        </a>

        <a href="boys.php" class="pagination-item">1</a>
        <a href="boys2.php" class="pagination-item">2</a>
        <span class="ellipsis">...</span>
        <a href="boys3.php" class="pagination-item">3</a>

        <a href="boys3.php" class="pagination-item">
            <img src="https://f.nooncdn.com/s/app/com/sivvi/design-system/icons-v2/chevron-forward.svg"
                alt="chevronForward" class="pagination-icon" loading="eager">
        </a>
    </div>
    
    <div class="c-footer" title="back to top">
        <button id="backtotop">&#8593;</button>
    </div>
    
   
</body>

</html>
