<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 0);

// Include the database connection file
include('db.php');

// Initialize variables for username, email, and password
$username = $email = $password = '';
// Initialize an array to store validation errors
$errors = array('username' => '', 'email' => '', 'password' => '');

// Sign up
if (isset($_POST['signup'])) {
    // Validation for username
    if (empty($_POST['username'])) {
        $errors['username'] = 'A username is required <br />';
    } else {
        $username = $_POST['username'];
        if (!preg_match('/^[a-zA-Z0-9\s]+$/', $username)) {
            $errors['username'] = 'Must be more than one letter/number';
        }
    }

    // Validation for email
    if (empty($_POST['email'])) {
        $errors['email'] = 'An email is required <br />';
    } else {
        $email = $_POST['email'];
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $errors['email'] = 'Must be a valid email';
        }
    }

    // Validation for password
    if (empty($_POST['password'])) {
        $errors['password'] = 'A password is required <br />';
    } else {
        $password = $_POST['password'];

        // Password conditions
        if (strlen($password) < 8) {
            $errors['password'] = 'Password must be at least 8 characters long';
        } elseif (!preg_match('/[A-Z]/', $password)) {
            $errors['password'] = 'Password must contain at least one uppercase letter';
        } elseif (!preg_match('/[a-z]/', $password)) {
            $errors['password'] = 'Password must contain at least one lowercase letter';
        } elseif (!preg_match('/[0-9]/', $password)) {
            $errors['password'] = 'Password must contain at least one digit';
        }
    }

    if (array_filter($errors)) {
        // If there are errors, display a message
        echo 'There is something wrong with the sign-up form!';
    } else {
        // Check if user already exists in the database
        $query = "SELECT * FROM users WHERE username = ? OR email = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ss", $username, $email);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            // User already exists, display appropriate message or redirect to login page
            echo 'User already exists. Display appropriate message or redirect to login page.';
        } else {
            // Hash the password
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

            // Insert new user with hashed password
            $query = "INSERT INTO users (username, email, password) VALUES (?, ?, ?)";
            $stmt = $conn->prepare($query);
            $stmt->bind_param("sss", $username, $email, $hashedPassword);

            if ($stmt->execute()) {
                // Sign up successful, redirect to home page
                echo 'Sign up successful! Redirecting to home page...';
                $_SESSION['username'] = $username;
                // Set the showWelcomeMessage session variable
                $_SESSION['showWelcomeMessage'] = true;

                header('location: home.php'); // Redirect to home page
                exit;
            } else {
                // If there is an error in the SQL execution, display the error
                echo "Error: " . $stmt->error;
            }
        }
    }
}

// Sign In
if (isset($_POST['signin'])) {
    // Validation for email
    if (empty($_POST['signin_email'])) {
        $errors['signin_email'] = 'An email is required for sign-in <br />';
    } else {
        $signin_email = $_POST['signin_email'];
        if (!filter_var($signin_email, FILTER_VALIDATE_EMAIL)) {
            $errors['signin_email'] = 'Must be a valid email';
        }
    }

    // Validation for password
    if (empty($_POST['signin_password'])) {
        $errors['signin_password'] = 'A password is required for sign-in <br />';
    } else {
        $signin_password = $_POST['signin_password'];
    }

    if (array_filter($errors)) {
        // If there are errors, display a message
        echo 'There is something wrong with the sign-in form!';
    } else {
        // Verify credentials
        $query = "SELECT * FROM users WHERE email = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("s", $signin_email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            // User found, check password
            $user = $result->fetch_assoc();
            if (password_verify($signin_password, $user['password'])) {
                $_SESSION['username'] = $user['username'];
                // Set the showWelcomeMessage 
                $_SESSION['showWelcomeMessage'] = true;

                header('location: home.php');
                exit;
            } else {
                // Incorrect password, display a message
                echo 'Incorrect password. Please try again.';
            }
        } else {
            // User not found, display a message
            echo 'User not found. Please sign up.';
        }
    }
}
// Close the database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <link rel="stylesheet" href="path/to/bootstrap/css/bootstrap.min.css">
    <script src="path/to/bootstrap/js/bootstrap.bundle.min.js"></script>

    <link rel="stylesheet" href="style1.css">
    <script src="script1.js" type="text/javascript"></script>
    <title>GlowUp - Your Fashion Destination</title>
</head>
<body>
    <!-- Container for the sign-up and sign-in forms -->
    <div class="container" id="container">
        <!-- Sign-up form -->
        <div class="form-container sign-up-container">
            <form action="" method="POST" name="signupForm">
                <h1>Create Account</h1>
                <!-- Social icons for alternative sign-up -->
                <div class="social-icons">
                    <a href="#" class="icon"><i class="fab fa-google-plus-g"></i></a>
                    <a href="#" class="icon"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" class="icon"><i class="fab fa-whatsapp"></i></a>
                    <a href="#" class="icon"><i class="fab fa-instagram"></i></a>
                    <a href="#" class="icon"><i class="fab fa-twitter"></i></a>
                </div>
                <!-- Form inputs for username, email, password -->
                <span>or use your email for registration</span>
                <input type="text" name="username" placeholder="username" value="<?php echo htmlspecialchars($username) ?>">
                <div class="red-text"><?php echo $errors['username']; ?></div>
                <input type="email" name="email" placeholder="Email" value="<?php echo htmlspecialchars($email) ?>">
                <div class="red-text"><?php echo $errors['email']; ?></div>
                <input type="password" name="password" placeholder="Password" value="<?php echo htmlspecialchars($password) ?>">
                <div class="red-text"><?php echo $errors['password']; ?></div>
                <!-- Submit button for sign-up -->
                <button type="submit" name="signup" value="Sign Up">Sign Up</button>
            </form>
        </div>
        
         <!-- Sign-in form -->
        <div class="form-container sign-in-container">
            <form action="" method="POST" name="signinForm">
                <h1>Sign In</h1>
                <!-- Social icons for alternative sign-in -->
                <div class="social-icons">
                    <a href="#" class="icon"><i class="fab fa-google-plus-g"></i></a>
                    <a href="#" class="icon"><i class="fab fa-facebook-f"></i></a>
                    <a href="#" class="icon"><i class="fab fa-whatsapp"></i></a>
                    <a href="#" class="icon"><i class="fab fa-instagram"></i></a>
                    <a href="#" class="icon"><i class="fab fa-twitter"></i></a>
                </div>
                <!-- Form inputs for email, password -->
                <span>or use your username and password</span>
                <input type="email" name="signin_email" placeholder="Email" value="<?php echo htmlspecialchars($signin_email) ?>">
                <div class="red-text"><?php echo $errors['email']; ?></div>
                <input type="password" name="signin_password" placeholder="Password" value="<?php echo htmlspecialchars($signin_password) ?>">
                <div class="red-text"><?php echo $errors['password']; ?></div>
                 <!-- Forgot password link -->
                <a href="reset password.html"class="mainbnr_wrap">
                <span class="button-border">Forgot Your Password?</span>
                </a>
                <!-- Submit button for sign-in -->
                <button type="submit" name="signin" value="Sign In">Sign In</button>
            </form>
        </div>

        <!-- Overlay container for switching between sign-up and sign-in -->
            <div class="overlay-container">
            <div class="overlay">
                 <!-- Left panel for sign-in -->
                <div class="overlay-panel overlay-left">
                    <h1>Welcome Back in GlowUp!</h1>
                    <p>Enter with your email and password to sign in</p>
                    <button class="ghost" id="signIn">Sign In</button>
                </div>
                <!-- Right panel for sign-up -->
                <div class="overlay-panel overlay-right">
                    <h1>Hello in GlowUp</h1>
                    <p>Enter your email and password to register in </p>
                    <button class="ghost" id="signUp">Sign Up</button>
                </div>
            </div>
        </div>
       

    </div>

</body>

</html>