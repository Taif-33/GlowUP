<!DOCTYPE html>
<html>

<head>
    <title>GlowUp-Clothes Women</title>
    <link rel="stylesheet" type="text/css" href="style4.css">

    <script src="script4.js"></script>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">

</head>

<body>
<header>
<nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
    <div class="container">
        <a class="navbar-brand" href="#">
            <h4>
                <em>GlowUp</em>
            </h4>
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
            data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
            aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>

        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item">
                    <a class="nav-link" href="Women.php">Women</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="Men.php">Men</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="girls.php">Kids girls</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="boys.php">Kids boys</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="ShoppingBag.php">
                        <img src="https://th.bing.com/th/id/OIP.SlPKG8oNNf7REyoldslkIQHaHa?rs=1&pid=ImgDetMain" alt="Shopping Bag" width="20" height="20"> Shopping Bag
                    </a>
                </li>
            </ul>
        </div>
    </div>
</nav>

</header>


    <div class="product-cards-container">

        <div class="product-card">
            <div class="shoe-details">
                <img src="https://rino-pelle.com/cdn/shop/files/Janou.7002312_blanc_02.jpg?v=1692020914&width=720"
                    alt="Product 1">
                <span class="shoe-name">Dress sweater</span>
                <p>This dress sweater is made from high-quality materials and features a stylish design that is perfect
                    for any occasion.<br />
                    It offers a comfortable fit and is available in multiple colors and sizes.<br />
                    Choose your preferred color and size from the options below and add this trendy dress sweater to
                    your wardrobe today!</p>
                <div class="stars bx">
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bx-star"></i>
                </div>
            </div>

            <div class="color-size-price">
                <div class="color-option">
                    <span class="color">Color:</span>
                    <div class="circles">
                        <span class="circle beige active" id="beige"></span>
                        <span class="circle black" id="black"></span>
                        <span class="circle brown" id="brown"></span>
                    </div>
                </div>


                <div class="size-option">
                    <span class="size">Size:</span>
                    <div class="sizes">
                        <span class="size-option">XS</span>
                        <span class="size-option">S</span>
                        <span class="size-option">M</span>
                        <span class="size-option">L</span>
                        <span class="size-option">XL</span>
                    </div>
                </div>

                <div class="price">
                    <span class="price_num">$239.99</span>
                </div>
            </div>

            <div class="button">
                <button class="add-to-bag">Add to Bag</button>
            </div>
        </div>





        <div class="product-card">
            <div class="shoe-details">
                <img src="https://rino-pelle.com/cdn/shop/files/Railey.7002311_black-white-strokes_01.jpg?v=1689863147"
                    alt="Product 2">
                <span class="shoe-name">Blouse</span>
                <p>This blouse is made from high-quality fabric and features a trendy design that is perfect for any
                    occasion.<br />
                    Its comfortable fit and stylish details make it a must-have addition to your wardrobe. Pair it with
                    your
                    favorite jeans or a skirt for a chic and fashionable look.</p>
                <div class="stars bx">
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bx-star"></i>
                </div>
            </div>

            <div class="color-size-price">
                <div class="color-option">
                    <span class="color">Color:</span>
                    <div class="circles">
                        <span class="circle beige active" id="beige"></span>
                        <span class="circle black" id="black"></span>
                        <span class="circle brown" id="brown"></span>
                    </div>
                </div>
                <div class="size-option">
                    <span class="size">Size:</span>
                    <div class="sizes">
                        <span class="size-option">XS</span>
                        <span class="size-option">S</span>
                        <span class="size-option">M</span>
                        <span class="size-option">L</span>
                        <span class="size-option">XL</span>
                    </div>
                </div>

                <div class="price">
                    <span class="price_num">$399.99</span>
                </div>
            </div>

            <div class="button">
                <button class="add-to-bag">Add to Bag</button>
            </div>
        </div>


        <div class="product-card">
            <div class="shoe-details">
                <img src="https://rino-pelle.com/cdn/shop/files/Kelson.7002313_blanc_01.jpg?v=1699538482"
                    alt="Product 3">
                <span class="shoe-name">Cardigan and Blouse</span>
                <p>A stylish and comfortable cardigan and blouse set that is perfect for both casual and formal
                    occasions.<br />
                    The cardigan features a soft and cozy fabric, while the blouse is made from a lightweight and
                    breathable material.<br />
                    The set can be easily paired with jeans, skirts, or trousers for a versatile and trendy look.</p>
                <div class="stars bx">
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bx-star"></i>
                </div>
            </div>

            <div class="color-size-price">
                <div class="color-option">
                    <span class="color">Color:</span>
                    <div class="circles">
                        <span class="circle beige active" id="beige"></span>
                        <span class="circle black" id="black"></span>
                        <span class="circle brown" id="brown"></span>
                    </div>
                </div>


                <div class="size-option">
                    <span class="size">Size:</span>
                    <div class="sizes">
                        <span class="size-option">XS</span>
                        <span class="size-option">S</span>
                        <span class="size-option">M</span>
                        <span class="size-option">L</span>
                        <span class="size-option">XL</span>
                    </div>
                </div>

                <div class="price">
                    <span class="price_num">$249.99</span>
                </div>
            </div>

            <div class="button">
                <button class="add-to-bag">Add to Bag</button>
            </div>
        </div>


        <div class="product-card">
            <div class="shoe-details">
                <img src="https://rino-pelle.com/cdn/shop/files/Kai.7002311_taupe_01.jpg?v=1690444543" alt="Product 4">
                <span class="shoe-name">Dinty sweater</span>
                <p>A cozy and stylish sweater for any occasion. Made from high-quality materials, the Dinty sweater
                    offers both comfort and fashion.<br />
                    Its soft fabric keeps you warm during chilly days, while the trendy design adds a touch of elegance
                    to your outfit.<br />
                    Choose your preferred color and size to make a fashion statement.</p>
                <div class="stars bx">
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bx-star"></i>
                </div>
            </div>
            <div class="color-size-price">
                <div class="color-option">
                    <span class="color">Color:</span>
                    <div class="circles">
                        <span class="circle beige active" id="beige"></span>
                        <span class="circle black" id="black"></span>
                        <span class="circle brown" id="brown"></span>
                    </div>
                </div>


                <div class="size-option">
                    <span class="size">Size:</span>
                    <div class="sizes">
                        <span class="size-option">XS</span>
                        <span class="size-option">S</span>
                        <span class="size-option">M</span>
                        <span class="size-option">L</span>
                        <span class="size-option">XL</span>
                    </div>
                </div>

                <div class="price">
                    <span class="price_num">$299.99</span>
                </div>
            </div>

            <div class="button">
                <button class="add-to-bag">Add to Bag</button>
            </div>
        </div>


        <div class="product-card">
            <div class="shoe-details">
                <img src="https://rino-pelle.com/cdn/shop/files/Jix.7002310_caramel_02.jpg?v=1692190646&width=720"
                    alt="Product 5">
                <span class="shoe-name">Coat</span>
                <p>This stylish coat is perfect for all seasons. It features a comfortable fit and high-quality<br />
                    materials to keep you warm and stylish. Available in various colors and sizes.</p>
                <div class="stars bx">
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bx-star"></i>
                </div>
            </div>

            <div class="color-size-price">
                <div class="color-option">
                    <span class="color">Color:</span>
                    <div class="circles">
                        <span class="circle beige active" id="beige"></span>
                        <span class="circle black" id="black"></span>
                        <span class="circle brown" id="brown"></span>
                    </div>
                </div>


                <div class="size-option">
                    <span class="size">Size:</span>
                    <div class="sizes">
                        <span class="size-option">XS</span>
                        <span class="size-option">S</span>
                        <span class="size-option">M</span>
                        <span class="size-option">L</span>
                        <span class="size-option">XL</span>
                    </div>
                </div>

                <div class="price">
                    <span class="price_num">$244.99</span>
                </div>
            </div>

            <div class="button">
                <button class="add-to-bag">Add to Bag</button>
            </div>
        </div>


        <div class="product-card">
            <div class="shoe-details">
                <img src="https://rino-pelle.com/cdn/shop/files/Jing.7002310_stone_01.jpg?v=1692020553" alt="Product 6">
                <span class="shoe-name">Coat</span>
                <p>This stylish coat is perfect for all seasons. It features a comfortable fit and high-quality<br />
                    materials to keep you warm and stylish. Available in various colors and sizes.</p>
                <div class="stars bx">
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bxs-star"></i>
                    <i class="bx bx-star"></i>
                </div>
            </div>
            <div class="color-size-price">
                <div class="color-option">
                    <span class="color">Color:</span>
                    <div class="circles">
                        <span class="circle beige active" id="beige"></span>
                        <span class="circle black" id="black"></span>
                        <span class="circle brown" id="brown"></span>
                    </div>
                </div>


                <div class="size-option">
                    <span class="size">Size:</span>
                    <div class="sizes">
                        <span class="size-option">XS</span>
                        <span class="size-option">S</span>
                        <span class="size-option">M</span>
                        <span class="size-option">L</span>
                        <span class="size-option">XL</span>
                    </div>
                </div>

                <div class="price">
                    <span class="price_num">$229.99</span>
                </div>
            </div>

            <div class="button">
                <button class="add-to-bag">Add to Bag</button>
            </div>
        </div>

    </div>


    <div class="pagination-container">
        <a href="Women.php" class="pagination-item">
            <img src="https://f.nooncdn.com/s/app/com/sivvi/design-system/icons-v2/chevron-back.svg" alt="chevronBack"
                class="pagination-icon" loading="eager">
        </a>
        
        <a href="Women.php" class="pagination-item">1</a>
        <a href="Women2.php" class="pagination-item">2</a>
        <span class="ellipsis">...</span>
        <a href="Women3.php" class="pagination-item">3</a>

        <a href="Women3.php" class="pagination-item">
            <img src="https://f.nooncdn.com/s/app/com/sivvi/design-system/icons-v2/chevron-forward.svg"
                alt="chevronForward" class="pagination-icon" loading="eager">
        </a>
    </div>

    <div class="c-footer" title="back to top">
        <button id="backtotop">&#8593;</button>
    </div>

</body>

</html>