<?php
// Start the session to manage user sessions
session_start();

// Check if the user is not logged in; if not, redirect to the login page
if (!isset($_SESSION['username'])) {
    header('location: login.php');
    exit(); // Stop further execution of the script
}

// Variable to control the display of the welcome message
$showWelcomeMessage = false;

?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>GlowUp - Home Page</title>

    <link rel="stylesheet" type="text/css" href="style2.css">

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-C6RzsynM9kWDrMNeT87bh95OGNyZPhcTNXj1NW7RuBCsyN/o0jlpcV8Qyq46cDfL"
        crossorigin="anonymous"></script>

</head>

<body>
<div id="welcomeMessage"></div>

<script>
    document.addEventListener('DOMContentLoaded', function () {
        const welcomeMessage = document.getElementById('welcomeMessage');

        // Check if the welcome message should be displayed
        const shouldDisplayWelcomeMessage = <?php echo isset($_SESSION['showWelcomeMessage']) ? 'true' : 'false'; ?>;
        
        if (shouldDisplayWelcomeMessage) {
            const username = '<?php echo $_SESSION['username']; ?>';

            // Create a div element for the colored square
            const coloredSquare = document.createElement('div');
            coloredSquare.classList.add('colored-square');

            // Set the background color of the colored square
            coloredSquare.style.backgroundColor = '#C5AB96';

            // Create a div element for the welcome message
            const welcomeMessageDiv = document.createElement('div');
            welcomeMessageDiv.textContent = 'Welcome to GlowUp, ' + username + '!';

            // Append the welcome message div to the colored square
            coloredSquare.appendChild(welcomeMessageDiv);

            // Append the colored square to the welcomeMessage container
            welcomeMessage.appendChild(coloredSquare);

            // Show the welcome message container
            welcomeMessage.style.display = 'block';

            // Hide the welcome message after 8 seconds 
            setTimeout(function () {
                welcomeMessage.style.display = 'none';
            }, 8000);

            // Remove the session variable to prevent showing the message on page reload
            <?php unset($_SESSION['showWelcomeMessage']); ?>;
        }
    });
</script>

<!-- Header Section -->
<header>
    <!-- Navigation Bar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <!-- Container for navigation elements -->
        <div class="container">
            <!-- Brand/logo -->
            <a class="navbar-brand" href="#">
                <h4>
                    <em>GlowUp</em>
                </h4>
            </a>
            <!-- Toggler button for small screens -->
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse"
                data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent"
                aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>

            <!-- Navigation links -->
            <div class="collapse navbar-collapse" id="navbarSupportedContent">
                <ul class="navbar-nav mr-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="Women.php">Women</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="Men.php">Men</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="girls.php">Kids girls</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="boys.php">Kids boys</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="ShoppingBag.php">
                            <img src="https://th.bing.com/th/id/OIP.SlPKG8oNNf7REyoldslkIQHaHa?rs=1&pid=ImgDetMain"
                                alt="Shopping Bag" width="20" height="20"> Shopping Bag
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>
</header>

<!-- Main Content Section -->
<div id="shopify-section-template--19799974773067__264455d4-f47a-4ee6-93df-555e68d05dbf" class="shopify-section">
    <!-- Main Banner Section -->
    <section class="section-main-banner firstbnr_cls section-id-template--19799974773067__264455d4-f47a-4ee6-93df-555e68d05dbf">
        <!-- Row for banner content -->
        <div class="row b_imgdatarow">
            <!-- Banner content snippet -->
            <div class="snippet-main-banner bnr_template--19799974773067__264455d4-f47a-4ee6-93df-555e68d05dbf full-width">
                <!-- Video container -->
                <div class="video-container">
                    <!-- Video element -->
                    <video playsinline="true" preload="metadata" muted="muted" loop="loop" autoplay="autoplay"
                        class="fullvideo"
                        poster="//rino-pelle.com/cdn/shop/files/preview_images/4a1df70d39124f5c89199bdb769a96ab.thumbnail.0000000000_small.jpg?v=1694531101">
                        <source
                            src="https://cdn.shopify.com/videos/c/vp/4a1df70d39124f5c89199bdb769a96ab/4a1df70d39124f5c89199bdb769a96ab.HD-1080p-7.2Mbps-18326668.mp4"
                            type="video/mp4">
                        <img
                            src="//rino-pelle.com/cdn/shop/files/preview_images/4a1df70d39124f5c89199bdb769a96ab.thumbnail.0000000000_small.jpg?v=1694531101">
                    </video>
                    <!-- Video content overlay -->
                    <div class="video-content">
                        <h1>
                            <em>GlowUp</em>
                        </h1>
                        <h3>
                            <em>Discover Your Style</em>
                        </h3>
                        <p>
                            <em>Get inspired by our curated collection of fashionable clothing</em>
                        </p>
                        <a href="GlowUp.php" class="mainbnr_wrap">
                            <span class="button-border">Discover now</span>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>
</div>

<!-- Divider Section -->
<div class="b-example-divider">
    <!-- Container for footer -->
    <div class="container">
        <!-- Footer Section -->
        <footer class="py-5">
            <!-- Row for footer content -->
            <div class="row">
                <!-- Company Info Section -->
                <div class="col-6 col-md-2 mb-3-expand-md ">
                    <h5>Company info</h5>
                    <ul class="nav flex-column">
                        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">About GlowUp</a>
                        </li>
                        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Fashion
                                Blogger</a></li>
                        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Features</a></li>
                    </ul>
                </div>

                <!-- Help Section -->
                <div class="col-6 col-md-2 mb-3-expand-md">
                    <h5>Help </h5>
                    <ul class="nav flex-column">
                        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Shipping Info</a>
                        </li>
                        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Returns</a></li>
                        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Refund</a></li>
                    </ul>
                </div>

                <!-- Customer Care Section -->
                <div class="col-6 col-md-2 mb-3-expand-md">
                    <h5>customer care</h5>
                    <ul class="nav flex-column">
                        <li class="nav-item mb-2"><a href="/contact Us/5.3/"
                                class="nav-link p-0 text-body-secondary">Contact Us</a>
                        </li>
                        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Payment
                                Method</a></li>
                        <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Bonus Point</a>
                        </li>
                    </ul>
                </div>

                <!-- Logo and Form Section -->
                <div class="col-md-5 offset-md-1 mb-3-expand-md">
                    <form>
                        <img src="logo.jpg" alt="GlowUp logo" class="logo">
                        <div class="d-flex flex-column flex-sm-row w-100 gap-2">
                        </div>
                    </form>
                </div>
            </div>

            <div class="d-flex flex-column flex-sm-row justify-content-between py-4 my-4 border-top-expand-sm">
                <div class="container">
                    <!-- Footer content -->
                    <p>&copy; 2023 GlowUp, All rights reserved.</p>
                     <!-- Social media icons -->
                    <i class="bi bi-instagram">
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                            class="bi bi-instagram" viewBox="0 0 16 16">
                            <path
                                d="M8 0C5.829 0 5.556.01 4.703.048 3.85.088 3.269.222 2.76.42a3.917 3.917 0 0 0-1.417.923A3.927 3.927 0 0 0 .42 2.76C.222 3.268.087 3.85.048 4.7.01 5.555 0 5.827 0 8.001c0 2.172.01 2.444.048 3.297.04.852.174 1.433.372 1.942.205.526.478.972.923 1.417.444.445.89.719 1.416.923.51.198 1.09.333 1.942.372C5.555 15.99 5.827 16 8 16s2.444-.01 3.298-.048c.851-.04 1.434-.174 1.943-.372a3.916 3.916 0 0 0 1.416-.923c.445-.445.718-.891.923-1.417.197-.509.332-1.09.372-1.942C15.99 10.445 16 10.173 16 8s-.01-2.445-.048-3.299c-.04-.851-.175-1.433-.372-1.941a3.926 3.926 0 0 0-.923-1.417A3.911 3.911 0 0 0 13.24.42c-.51-.198-1.092-.333-1.943-.372C10.443.01 10.172 0 7.998 0h.003zm-.717 1.442h.718c2.136 0 2.389.007 3.232.046.78.035 1.204.166 1.486.275.373.145.64.319.92.599.28.28.453.546.598.92.11.281.24.705.275 1.485.039.843.047 1.096.047 3.231s-.008 2.389-.047 3.232c-.035.78-.166 1.203-.275 1.485a2.47 2.47 0 0 1-.599.919c-.28.28-.546.453-.92.598-.28.11-.704.24-1.485.276-.843.038-1.096.047-3.232.047s-2.39-.009-3.233-.047c-.78-.036-1.203-.166-1.485-.276a2.478 2.478 0 0 1-.92-.598 2.48 2.48 0 0 1-.6-.92c-.109-.281-.24-.705-.275-1.485-.038-.843-.046-1.096-.046-3.233 0-2.136.008-2.388.046-3.231.036-.78.166-1.204.276-1.486.145-.373.319-.64.599-.92.28-.28.546-.453.92-.598.282-.11.705-.24 1.485-.276.738-.034 1.024-.044 2.515-.045v.002zm4.988 1.328a.96.96 0 1 0 0 1.92.96.96 0 0 0 0-1.92zm-4.27 1.122a4.109 4.109 0 1 0 0 8.217 4.109 4.109 0 0 0 0-8.217zm0 1.441a2.667 2.667 0 1 1 0 5.334 2.667 2.667 0 0 1 0-5.334z" />
                        </svg>
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                            class="bi bi-whatsapp" viewBox="0 0 16 16">
                            <path
                                d="M13.601 2.326A7.854 7.854 0 0 0 7.994 0C3.627 0 .068 3.558.064 7.926c0 1.399.366 2.76 1.057 3.965L0 16l4.204-1.102a7.933 7.933 0 0 0 3.79.965h.004c4.368 0 7.926-3.558 7.93-7.93A7.898 7.898 0 0 0 13.6 2.326zM7.994 14.521a6.573 6.573 0 0 1-3.356-.92l-.24-.144-2.494.654.666-2.433-.156-.251a6.56 6.56 0 0 1-1.007-3.505c0-3.626 2.957-6.584 6.591-6.584a6.56 6.56 0 0 1 4.66 1.931 6.557 6.557 0 0 1 1.928 4.66c-.004 3.639-2.961 6.592-6.592 6.592zm3.615-4.934c-.197-.099-1.17-.578-1.353-.646-.182-.065-.315-.099-.445.099-.133.197-.513.646-.627.775-.114.133-.232.148-.43.05-.197-.1-.836-.308-1.592-.985-.59-.525-.985-1.175-1.103-1.372-.114-.198-.011-.304.088-.403.087-.088.197-.232.296-.346.1-.114.133-.198.198-.33.065-.134.034-.248-.015-.347-.05-.099-.445-1.076-.612-1.47-.16-.389-.323-.335-.445-.34-.114-.007-.247-.007-.38-.007a.729.729 0 0 0-.529.247c-.182.198-.691.677-.691 1.654 0 .977.71 1.916.81 2.049.098.133 1.394 2.132 3.383 2.992.47.205.84.326 1.129.418.475.152.904.129 1.246.08.38-.058 1.171-.48 1.338-.943.164-.464.164-.86.114-.943-.049-.084-.182-.133-.38-.232z" />
                        </svg>
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                            class="bi bi-facebook" viewBox="0 0 16 16">
                            <path
                                d="M16 8.049c0-4.446-3.582-8.05-8-8.05C3.58 0-.002 3.603-.002 8.05c0 4.017 2.926 7.347 6.75 7.951v-5.625h-2.03V8.05H6.75V6.275c0-2.017 1.195-3.131 3.022-3.131.876 0 1.791.157 1.791.157v1.98h-1.009c-.993 0-1.303.621-1.303 1.258v1.51h2.218l-.354 2.326H9.25V16c3.824-.604 6.75-3.934 6.75-7.951z" />
                        </svg>
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                            class="bi bi-twitter-x" viewBox="0 0 16 16">
                            <path
                                d="M12.6.75h2.454l-5.36 6.142L16 15.25h-4.937l-3.867-5.07-4.425 5.07H.316l5.733-6.57L0 .75h5.063l3.495 4.633L12.601.75Zm-.86 13.028h1.36L4.323 2.145H2.865l8.875 11.633Z" />
                        </svg>
                        <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" fill="currentColor"
                            class="bi bi-tiktok" viewBox="0 0 16 16">
                            <path
                                d="M9 0h1.98c.144.715.54 1.617 1.235 2.512C12.895 3.389 13.797 4 15 4v2c-1.753 0-3.07-.814-4-1.829V11a5 5 0 1 1-5-5v2a3 3 0 1 0 3 3V0Z" />
                        </svg>
                        
                        <div>
                            <!-- Payment icons -->
                            <a class="text-decoration-none me-3" href="#"><img src="https://cdn.msaaq.com/assets/images/payments/applepay.svg" alt="Apple Pay" width="25" height="20"></a>
                            <a class="text-decoration-none me-3" href="#"><img src="https://cdn.msaaq.com/assets/images/payments/visa.svg" alt="Visa" width="25" height="20"></a>
                            <a class="text-decoration-none me-3" href="#"><img src="https://cdn.msaaq.com/assets/images/payments/master.svg" alt="Mastercard" width="25" height="20"></a>
                            <a class="text-decoration-none me-3" href="#"><img src="https://cdn.msaaq.com/assets/images/payments/mada.svg" alt="mada" width="25" height="20"></a>
                            <a class="text-decoration-none" href="#"><img src="https://www.annualgivingnetwork.com/wp-content/uploads/2018/04/iStock-1093968482-cropped-768x555.jpeg" alt="cash" width="25" height="20"></a>
                        </div>

                </div>
        </footer>
    </div>

</body>

</html>