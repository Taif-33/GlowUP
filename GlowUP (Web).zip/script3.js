document.addEventListener("DOMContentLoaded", function () {
  // Get all the "ADD TO BAG" buttons
  const addToBagButtons = document.querySelectorAll('.product button');

  // Add event listeners to each button
  addToBagButtons.forEach((button) => {
    button.addEventListener('click', addToBagClicked);
  });

  // "ADD TO BAG" button click
  function addToBagClicked(event) {
    // button
    const productContainer = event.target.closest('.product');

    if (productContainer) {
      // Get the product information
      const productName = productContainer.querySelector('h4').textContent;
      const productPrice = productContainer.querySelector('.price').textContent;
      console.log(`Product added to bag: ${productName}, Price: ${productPrice}`);
    } else {
      console.log("Product container not found.");
    }
  }

  window.addEventListener('scroll', function () {
    if (window.scrollY > 200) {
      document.body.classList.add('scrolled');
    } else {
      document.body.classList.remove('scrolled');
    }
  });

  // Get the back to top button by id
  const backToTopButton = document.getElementById('backtotop');

  // Add event listener to the back to top button
  backToTopButton.addEventListener('click', function () {
    window.scrollTo({
      top: 0,
      behavior: 'smooth'
    });
  });
});
